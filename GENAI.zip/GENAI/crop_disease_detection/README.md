# 🌿 Crop Disease Detection + Instant Resolution System

An AI-powered system that detects crop diseases from plant leaf images and provides instant solutions with causes, treatments, organic alternatives, and prevention tips.

## 🎯 Features

✅ **Disease Detection** - AI identifies crop diseases from leaf images
📌 **Confidence Score** - Shows accuracy percentage of prediction  
🦠 **Disease Information** - Explains what causes the disease
💊 **Treatment Options** - Professional recommended treatments
🌿 **Organic Alternatives** - Natural, eco-friendly solutions
🛡️ **Prevention Tips** - How to prevent disease in future

## 📊 Supported Crops & Diseases

### Tomato
- Early Blight
- Late Blight
- Septoria Leaf Spot
- Bacterial Speck
- Powdery Mildew
- Yellow Leaf Curl Virus

### Potato
- Early Blight
- Late Blight
- Leaf Scorch

### Corn
- Northern Leaf Blight
- Gray Leaf Spot

Plus **Healthy Leaf** detection for normal plants.

## 🏗️ Project Structure

```
crop_disease_detection/
├── backend/
│   ├── app.py                 # Flask API server
│   └── requirements.txt        # Python dependencies
├── frontend/
│   └── index.html             # Web interface
├── models/
│   ├── train_model.py         # Model training script
│   └── plant_disease_model.h5 # Trained model (after training)
├── data/
│   └── disease_database.json  # Disease information DB
├── uploads/                   # Uploaded images folder
├── infer.py                   # Quick inference script
└── README.md                  # This file
```

## 🚀 Quick Start

### Option 1: Web Interface (Recommended)

#### Step 1: Setup Backend
```bash
# Navigate to backend directory
cd backend

# Install dependencies
pip install -r requirements.txt
```

#### Step 2: Download Pre-trained Model (Optional)
If you don't have a trained model yet, the system provides inference utilities. 
For production, train using PlantVillage dataset (see below).

#### Step 3: Start Flask Server
```bash
python app.py
```
Server runs on: `http://localhost:5000`

#### Step 4: Open Web Interface
- Open `frontend/index.html` in a web browser
- Or use Python HTTP server: `python -m http.server 8000` in the frontend directory

#### Step 5: Upload & Analyze
1. Click to upload a plant leaf image
2. Click "Analyze Image"
3. View instant results with treatment options

### Option 2: Command Line Inference
```bash
# From project root directory
python infer.py uploads/leaf_image.jpg
```

## 🧠 Model Training

### Prerequisites
- TensorFlow 2.12+
- 2GB+ RAM
- GPU recommended for faster training

### Step 1: Download PlantVillage Dataset

Download from [Kaggle](https://www.kaggle.com/datasets/emmarex/plantvillage-dataset):

```bash
# After downloading, organize as:
data/
└── plant_images/
    ├── train/
    │   ├── Tomato__Early_blight/
    │   ├── Tomato__Late_blight/
    │   └── ...
    └── val/
        ├── Tomato__Early_blight/
        └── ...
```

### Step 2: Train Model
```bash
cd models
python train_model.py
```

Training will:
- Use MobileNetV2 architecture (lightweight & fast)
- Train on your dataset
- Save model to `models/plant_disease_model.h5`
- Takes ~20-30 minutes on GPU, 1-2 hours on CPU

### Step 3: Load Model in API
The Flask app will automatically load the model when it starts.

## 📚 API Endpoints

### POST /predict
Predict disease from image
```bash
curl -X POST -F "image=@leaf.jpg" http://localhost:5000/predict
```

**Response:**
```json
{
  "success": true,
  "prediction": {
    "disease": "Tomato__Early_blight",
    "confidence": 92.34,
    "cause": "Fungus: Alternaria solani...",
    "treatment": "Apply fungicides...",
    "organic_alternative": "Use Copper-based fungicide...",
    "prevention": "Avoid overhead watering..."
  }
}
```

### GET /health
Check API status
```bash
curl http://localhost:5000/health
```

### GET /diseases
Get all diseases in database
```bash
curl http://localhost:5000/diseases
```

### GET /disease/<id>
Get specific disease details
```bash
curl http://localhost:5000/disease/1
```

## 🛠️ Installation Details

### Requirements
- Python 3.8+
- TensorFlow 2.12.0
- Flask 2.3.0
- PIL/Pillow
- NumPy

### Full Setup
```bash
# Clone/download project
cd crop_disease_detection

# Create virtual environment (recommended)
python -m venv venv
source venv/Scripts/activate  # On Windows

# Install all dependencies
pip install flask flask-cors tensorflow keras pillow numpy werkzeug

# Or from requirements.txt
pip install -r backend/requirements.txt
```

## 📸 Supported Image Formats
- PNG
- JPG / JPEG
- GIF
- Max size: 16MB

## ⚙️ Configuration

### Backend Configuration (app.py)
```python
UPLOAD_FOLDER = 'uploads'        # Where to save uploaded images
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
MAX_FILE_SIZE = 16 * 1024 * 1024  # 16MB max
```

### Model Configuration (train_model.py)
```python
IMG_SIZE = 224                    # Input image size
BATCH_SIZE = 32                   # Training batch size
EPOCHS = 20                       # Number of epochs
LEARNING_RATE = 0.001             # Learning rate
```

## 🔍 How It Works

1. **Image Upload** → User uploads plant leaf image via web interface
2. **Preprocessing** → Image resized to 224x224 and normalized
3. **Model Inference** → MobileNetV2 CNN predicts disease class
4. **Confidence Score** → System shows prediction confidence %
5. **Database Lookup** → Fetches detailed disease information
6. **Display Results** → Shows disease name, cause, treatment, alternatives, prevention

## 📊 Performance

- **Model**: MobileNetV2 (3.5M parameters)
- **Inference Speed**: ~100-300ms on CPU
- **Accuracy**: ~95%+ on PlantVillage dataset (after training)
- **Model Size**: ~14MB

## 🐛 Troubleshooting

### API Connection Error
```
"Error connecting to API"
```
**Solution:** Make sure Flask server is running on port 5000
```bash
python backend/app.py
```

### Model Not Loaded
```
"Model not loaded. Please load model first"
```
**Solution:** 
1. Train model first: `python models/train_model.py`
2. Or provide pre-trained model in `models/` folder
3. Start Flask server: `python backend/app.py`

### CORS Error in Browser
**Solution:** CORS is already enabled in Flask app. If still issues:
```python
# Already in app.py
from flask_cors import CORS
CORS(app)
```

### Image Format Error
**Solution:** Use supported formats: PNG, JPG, JPEG, GIF (max 16MB)

## 📝 Disease Database Structure

Each disease in `disease_database.json` contains:
```json
{
  "id": 1,
  "name": "Early Blight (Tomato)",
  "crop": "Tomato",
  "cause": "Fungus: Alternaria solani...",
  "treatment": "Apply fungicides...",
  "organic_alternative": "Use Copper-based fungicide...",
  "prevention": "Avoid overhead watering...",
  "confidence_threshold": 0.75
}
```

## 🎓 Learning Resources

- **Dataset**: [PlantVillage Dataset](https://www.kaggle.com/datasets/emmarex/plantvillage-dataset)
- **MobileNetV2**: [Paper](https://arxiv.org/abs/1801.04381)
- **TensorFlow**: [Documentation](https://www.tensorflow.org/)
- **Flask**: [Documentation](https://flask.palletsprojects.com/)

## 🤝 Contributing

Feel free to:
- Add more diseases to database
- Improve model accuracy with better training
- Add more crop types
- Enhance UI/UX
- Add mobile app support

## 📄 License

This project is open source and available for educational and commercial use.

## 🎯 Future Enhancements

- [ ] Mobile app (React Native/Flutter)
- [ ] Real-time camera detection
- [ ] Multi-disease detection
- [ ] Disease progression tracking
- [ ] Yield impact calculator
- [ ] Market price recommendations
- [ ] Farmer community forum
- [ ] SMS/WhatsApp integration

## 📞 Support

For issues or questions:
1. Check the Troubleshooting section
2. Review API endpoints documentation
3. Check Flask server logs
4. Verify dataset structure for training

---

**Built with ❤️ for farmers and agronomists worldwide**
