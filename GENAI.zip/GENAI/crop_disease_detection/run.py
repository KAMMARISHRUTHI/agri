#!/usr/bin/env python
"""
Simple launcher script for running the entire system
"""

import os
import sys
import subprocess
import webbrowser
from pathlib import Path

def check_requirements():
    """Check if required packages are installed"""
    required = ['flask', 'flask_cors', 'tensorflow', 'keras', 'PIL', 'numpy']
    missing = []
    
    for package in required:
        try:
            __import__(package)
        except ImportError:
            missing.append(package)
    
    return missing

def main():
    print("=" * 60)
    print("🌿 Crop Disease Detection System Launcher")
    print("=" * 60)
    
    # Check if we're in the right directory
    if not os.path.exists('backend/app.py'):
        print("❌ Error: Please run this script from the project root directory")
        sys.exit(1)
    
    # Check requirements
    print("\n🔍 Checking dependencies...")
    missing = check_requirements()
    
    if missing:
        print(f"❌ Missing packages: {', '.join(missing)}")
        print("\nInstall using:")
        print(f"   pip install {' '.join(missing)}")
        sys.exit(1)
    
    print("✅ All dependencies installed")
    
    # Create necessary directories
    print("\n📁 Creating directories...")
    os.makedirs('uploads', exist_ok=True)
    os.makedirs('logs', exist_ok=True)
    print("✅ Directories ready")
    
    # Check for model
    print("\n🤖 Checking for trained model...")
    if not os.path.exists('models/plant_disease_model.h5'):
        print("⚠️  No trained model found at models/plant_disease_model.h5")
        print("   You can still test the API, but predictions won't work until you train a model.")
        print("   To train: python models/train_model.py")
    else:
        print("✅ Model found")
    
    # Start Flask server
    print("\n" + "=" * 60)
    print("🚀 Starting Flask API Server...")
    print("=" * 60)
    print("Server will run at: http://localhost:5000")
    print("Web interface at: file:///$(pwd)/frontend/index.html")
    print("\nPress Ctrl+C to stop the server")
    print("=" * 60 + "\n")
    
    try:
        # Change to backend directory and run Flask
        os.chdir('backend')
        subprocess.run([sys.executable, 'app.py'])
    except KeyboardInterrupt:
        print("\n\n👋 Server stopped. Goodbye!")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ Error: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()
