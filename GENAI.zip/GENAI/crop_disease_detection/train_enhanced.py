"""
Enhanced model training with better synthetic data generation
Creates diverse training data for 12 crop diseases
"""

import os
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from PIL import Image, ImageDraw, ImageFilter
import random

IMG_SIZE = 224
BATCH_SIZE = 32
EPOCHS = 30
MODEL_SAVE_PATH = 'models/plant_disease_model.h5'

CLASS_NAMES = [
    'Tomato__Early_blight',      # 0
    'Tomato__Late_blight',       # 1
    'Tomato__Septoria_leaf_spot',# 2
    'Tomato__Bacterial_speck',   # 3
    'Tomato__Powdery_mildew',    # 4
    'Tomato__Yellow_leaf_curl_virus', # 5
    'Potato__Early_blight',      # 6
    'Potato__Late_blight',       # 7
    'Potato__Leaf_scorch',       # 8
    'Corn__Northern_leaf_blight',# 9
    'Corn__Gray_leaf_spot',      # 10
    'Healthy'                    # 11
]

def create_synthetic_leaf(disease_type, size=224):
    """Create synthetic leaf image with disease characteristics"""
    img = Image.new('RGB', (size, size), color=(255, 255, 255))
    draw = ImageDraw.Draw(img)
    
    # Base leaf color
    leaf_colors = {
        'Tomato__Early_blight': (34, 139, 34),      # Dark green with brown spots
        'Tomato__Late_blight': (46, 125, 50),       # Green with dark spots
        'Tomato__Septoria_leaf_spot': (56, 142, 60),# Green with small spots
        'Tomato__Bacterial_speck': (76, 175, 80),   # Light green with dark speck
        'Tomato__Powdery_mildew': (129, 199, 132),  # Pale green with white powder
        'Tomato__Yellow_leaf_curl_virus': (205, 220, 57), # Yellow-green with curl
        'Potato__Early_blight': (27, 94, 32),       # Dark green with brown spots
        'Potato__Late_blight': (51, 102, 51),       # Dark green with gray spots
        'Potato__Leaf_scorch': (85, 107, 47),       # Olive with brown edges
        'Corn__Northern_leaf_blight': (139, 195, 74), # Light green with gray spots
        'Corn__Gray_leaf_spot': (165, 214, 167),    # Very light green with spots
        'Healthy': (76, 175, 80)                    # Bright green
    }
    
    leaf_color = leaf_colors.get(disease_type, (76, 175, 80))
    
    # Draw leaf shape (ellipse)
    margin = size // 4
    draw.ellipse([margin, margin // 2, size - margin, size - margin // 2], 
                 fill=leaf_color, outline=(0, 100, 0), width=3)
    
    # Add disease-specific markings
    if 'Early_blight' in disease_type or 'Late_blight' in disease_type:
        # Brown/dark spots
        for _ in range(random.randint(8, 15)):
            x = random.randint(margin, size - margin)
            y = random.randint(size // 4, 3 * size // 4)
            radius = random.randint(8, 20)
            draw.ellipse([x - radius, y - radius, x + radius, y + radius],
                        fill=(139, 69, 19), outline=(101, 50, 15), width=2)
    
    elif 'Septoria' in disease_type:
        # Small circular spots with dark centers
        for _ in range(random.randint(15, 25)):
            x = random.randint(margin, size - margin)
            y = random.randint(size // 4, 3 * size // 4)
            radius = random.randint(4, 8)
            draw.ellipse([x - radius, y - radius, x + radius, y + radius],
                        fill=(110, 40, 40), outline=(60, 20, 20), width=1)
    
    elif 'Bacterial_speck' in disease_type:
        # Small dark specks
        for _ in range(random.randint(20, 35)):
            x = random.randint(margin, size - margin)
            y = random.randint(size // 4, 3 * size // 4)
            radius = random.randint(2, 4)
            draw.ellipse([x - radius, y - radius, x + radius, y + radius],
                        fill=(50, 20, 20))
    
    elif 'Powdery_mildew' in disease_type:
        # White powdery coating
        for _ in range(random.randint(50, 80)):
            x = random.randint(margin, size - margin)
            y = random.randint(size // 4, 3 * size // 4)
            radius = random.randint(2, 5)
            draw.ellipse([x - radius, y - radius, x + radius, y + radius],
                        fill=(240, 240, 240, 200))
    
    elif 'Yellow_leaf_curl_virus' in disease_type:
        # Yellow coloring with curl effect (transform edges)
        for _ in range(random.randint(10, 20)):
            x = random.randint(margin, size - margin)
            y = random.randint(size // 4, 3 * size // 4)
            radius = random.randint(3, 6)
            draw.ellipse([x - radius, y - radius, x + radius, y + radius],
                        fill=(255, 255, 100))
    
    elif 'Leaf_scorch' in disease_type or 'Northern_leaf_blight' in disease_type:
        # Brown/gray edges and spots
        for _ in range(random.randint(5, 12)):
            x = random.randint(margin, size - margin)
            y = random.randint(size // 4, 3 * size // 4)
            radius = random.randint(8, 15)
            draw.ellipse([x - radius, y - radius, x + radius, y + radius],
                        fill=(128, 128, 128), outline=(64, 64, 64), width=2)
    
    elif 'Gray_leaf_spot' in disease_type:
        # Small gray spots
        for _ in range(random.randint(15, 30)):
            x = random.randint(margin, size - margin)
            y = random.randint(size // 4, 3 * size // 4)
            radius = random.randint(4, 8)
            draw.ellipse([x - radius, y - radius, x + radius, y + radius],
                        fill=(169, 169, 169), outline=(128, 128, 128), width=1)
    
    # Apply slight blur for realism
    img = img.filter(ImageFilter.GaussianBlur(radius=0.5))
    
    return np.array(img)

def generate_synthetic_dataset(num_samples_per_class=100):
    """Generate synthetic dataset"""
    print("\n" + "="*70)
    print(f"GENERATING SYNTHETIC DATASET ({num_samples_per_class} samples per class)")
    print("="*70 + "\n")
    
    X = []
    y = []
    
    for class_idx, class_name in enumerate(CLASS_NAMES):
        print(f"Generating {class_name}...", end=" ", flush=True)
        
        for _ in range(num_samples_per_class):
            img_array = create_synthetic_leaf(class_name, IMG_SIZE)
            
            # Normalize
            img_array = img_array.astype('float32') / 255.0
            
            X.append(img_array)
            y.append(class_idx)
        
        print(f"✓ Generated {num_samples_per_class} samples")
    
    X = np.array(X)
    y = np.array(y)
    
    print(f"\nDataset shape: X={X.shape}, y={y.shape}")
    print(f"Total samples: {len(X)}")
    
    return X, y

def create_model():
    """Create improved model architecture"""
    print("\n" + "="*70)
    print("CREATING IMPROVED MODEL")
    print("="*70 + "\n")
    
    model = tf.keras.Sequential([
        tf.keras.layers.Input(shape=(IMG_SIZE, IMG_SIZE, 3)),
        
        # Data augmentation layers
        tf.keras.layers.RandomFlip("horizontal_and_vertical"),
        tf.keras.layers.RandomRotation(0.2),
        tf.keras.layers.RandomZoom(0.2),
        tf.keras.layers.RandomBrightness(0.2),
        tf.keras.layers.RandomContrast(0.2),
        
        # Convolutional blocks
        tf.keras.layers.Conv2D(32, (3, 3), activation='relu', padding='same'),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.Conv2D(32, (3, 3), activation='relu', padding='same'),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.MaxPooling2D((2, 2)),
        tf.keras.layers.Dropout(0.25),
        
        tf.keras.layers.Conv2D(64, (3, 3), activation='relu', padding='same'),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.Conv2D(64, (3, 3), activation='relu', padding='same'),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.MaxPooling2D((2, 2)),
        tf.keras.layers.Dropout(0.25),
        
        tf.keras.layers.Conv2D(128, (3, 3), activation='relu', padding='same'),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.Conv2D(128, (3, 3), activation='relu', padding='same'),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.MaxPooling2D((2, 2)),
        tf.keras.layers.Dropout(0.25),
        
        tf.keras.layers.Conv2D(256, (3, 3), activation='relu', padding='same'),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.Conv2D(256, (3, 3), activation='relu', padding='same'),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.MaxPooling2D((2, 2)),
        tf.keras.layers.Dropout(0.25),
        
        # Global Average Pooling
        tf.keras.layers.GlobalAveragePooling2D(),
        
        # Dense layers
        tf.keras.layers.Dense(512, activation='relu'),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.Dropout(0.5),
        
        tf.keras.layers.Dense(256, activation='relu'),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.Dropout(0.5),
        
        # Output layer
        tf.keras.layers.Dense(len(CLASS_NAMES), activation='softmax')
    ])
    
    return model

def train_model(X_train, y_train, X_val, y_val):
    """Train the model"""
    print("\n" + "="*70)
    print(f"TRAINING MODEL FOR {EPOCHS} EPOCHS")
    print("="*70 + "\n")
    
    model = create_model()
    
    # Compile model
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
        loss='sparse_categorical_crossentropy',
        metrics=['accuracy']
    )
    
    # Callbacks
    callbacks = [
        tf.keras.callbacks.EarlyStopping(
            monitor='val_loss',
            patience=5,
            restore_best_weights=True
        ),
        tf.keras.callbacks.ReduceLROnPlateau(
            monitor='val_loss',
            factor=0.5,
            patience=3,
            min_lr=1e-6,
            verbose=1
        )
    ]
    
    # Train
    history = model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val),
        batch_size=BATCH_SIZE,
        epochs=EPOCHS,
        callbacks=callbacks,
        verbose=1
    )
    
    return model, history

def main():
    print("\n")
    print("*" * 70)
    print("ENHANCED CROP DISEASE DETECTION MODEL TRAINING")
    print("*" * 70)
    
    # Generate synthetic dataset
    X, y = generate_synthetic_dataset(num_samples_per_class=150)
    
    # Split into train and validation
    split_idx = int(0.8 * len(X))
    indices = np.random.permutation(len(X))
    
    train_indices = indices[:split_idx]
    val_indices = indices[split_idx:]
    
    X_train = X[train_indices]
    y_train = y[train_indices]
    X_val = X[val_indices]
    y_val = y[val_indices]
    
    print(f"\nTrain set: {X_train.shape}")
    print(f"Validation set: {X_val.shape}")
    
    # Create and train model
    model, history = train_model(X_train, y_train, X_val, y_val)
    
    # Evaluate
    print("\n" + "="*70)
    print("EVALUATION")
    print("="*70 + "\n")
    
    val_loss, val_accuracy = model.evaluate(X_val, y_val, verbose=0)
    print(f"Validation Accuracy: {val_accuracy*100:.2f}%")
    print(f"Validation Loss: {val_loss:.4f}")
    
    # Save model
    os.makedirs(os.path.dirname(MODEL_SAVE_PATH), exist_ok=True)
    model.save(MODEL_SAVE_PATH)
    print(f"\n✓ Model saved to {MODEL_SAVE_PATH}")
    print(f"  File size: {os.path.getsize(MODEL_SAVE_PATH) / 1024 / 1024:.2f} MB")
    
    print("\n" + "*" * 70)
    print("TRAINING COMPLETE!")
    print("*" * 70 + "\n")

if __name__ == '__main__':
    main()
