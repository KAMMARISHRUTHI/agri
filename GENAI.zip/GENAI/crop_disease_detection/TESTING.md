"""
Testing and Demo Guide for Crop Disease Detection System
"""

# Quick Start Commands
QUICK_START = """
═══════════════════════════════════════════════════════════════
🚀 QUICK START GUIDE
═══════════════════════════════════════════════════════════════

1. INSTALL DEPENDENCIES
   cd backend
   pip install -r requirements.txt

2. START FLASK SERVER
   python app.py
   (or from project root: python run.py)

3. OPEN WEB INTERFACE
   Open in browser: frontend/index.html
   Or use: python -m http.server 8000 (in frontend folder)

4. UPLOAD & TEST
   - Click upload button
   - Select a leaf image
   - Click "Analyze Image"
   - View results!

═══════════════════════════════════════════════════════════════
"""

# Directory Structure
DIR_STRUCTURE = """
═══════════════════════════════════════════════════════════════
📁 PROJECT STRUCTURE
═══════════════════════════════════════════════════════════════

crop_disease_detection/
│
├── 📂 backend/
│   ├── app.py                    # Flask API (Main server)
│   └── requirements.txt           # Python packages
│
├── 📂 frontend/
│   └── index.html                # Web interface
│
├── 📂 models/
│   ├── train_model.py            # Training script
│   └── plant_disease_model.h5    # Trained model (after training)
│
├── 📂 data/
│   ├── disease_database.json     # Disease info database
│   └── plant_images/             # Training images (optional)
│       ├── train/
│       └── val/
│
├── 📂 uploads/                   # Uploaded images storage
│
├── 📂 logs/                      # Application logs
│
├── infer.py                      # Quick inference script
├── run.py                        # System launcher
├── config.ini                    # Configuration
├── README.md                     # Documentation
└── TESTING.md                    # This file

═══════════════════════════════════════════════════════════════
"""

# Testing Guide
TESTING_GUIDE = """
═══════════════════════════════════════════════════════════════
🧪 TESTING GUIDE
═══════════════════════════════════════════════════════════════

TEST 1: API Health Check
─────────────────────────
Command:
  curl http://localhost:5000/health

Expected Response:
  {"status": "healthy", "model": "loaded"}

TEST 2: Get All Diseases
───────────────────────
Command:
  curl http://localhost:5000/diseases

Expected Response:
  List of all diseases in database

TEST 3: Get Specific Disease Info
──────────────────────────────────
Command:
  curl http://localhost:5000/disease/1

Expected Response:
  {
    "id": 1,
    "name": "Early Blight (Tomato)",
    "cause": "...",
    "treatment": "...",
    etc.
  }

TEST 4: Upload Image & Predict
───────────────────────────────
Command:
  curl -X POST -F "image=@path/to/image.jpg" \\
    http://localhost:5000/predict

Expected Response:
  {
    "success": true,
    "prediction": {
      "disease": "Early Blight (Tomato)",
      "confidence": 92.34,
      "cause": "...",
      "treatment": "...",
      "organic_alternative": "...",
      "prevention": "..."
    }
  }

TEST 5: Web Interface
─────────────────────
1. Open frontend/index.html in browser
2. Click upload area
3. Select any image (JPG/PNG/GIF)
4. Click "Analyze Image"
5. View results

═══════════════════════════════════════════════════════════════
"""

# Troubleshooting
TROUBLESHOOTING = """
═══════════════════════════════════════════════════════════════
🔧 TROUBLESHOOTING
═══════════════════════════════════════════════════════════════

ISSUE: "ModuleNotFoundError: No module named 'flask'"
SOLUTION:
  pip install flask flask-cors tensorflow keras pillow numpy

ISSUE: "Model not found at models/plant_disease_model.h5"
SOLUTION:
  1. Train model: python models/train_model.py
  2. Or provide pre-trained model
  3. Model must be in models/ folder

ISSUE: "Error: Address already in use"
SOLUTION:
  Flask is already running on port 5000
  - Stop other Flask instances
  - Or change port in app.py: app.run(port=5001)

ISSUE: "CORS error in browser"
SOLUTION:
  CORS is already enabled in Flask (line: CORS(app))
  Make sure frontend is accessing: http://localhost:5000

ISSUE: "Image upload fails"
SOLUTION:
  - Check file format (PNG, JPG, JPEG, GIF)
  - Check file size (max 16MB)
  - Check uploads/ folder exists and is writable

ISSUE: "Prediction takes too long"
SOLUTION:
  - Normal: 100-300ms on CPU
  - GPU would be faster (~50ms)
  - Check system resources (RAM, CPU)

═══════════════════════════════════════════════════════════════
"""

# Performance Tips
PERFORMANCE_TIPS = """
═══════════════════════════════════════════════════════════════
⚡ PERFORMANCE OPTIMIZATION
═══════════════════════════════════════════════════════════════

1. Use GPU for inference
   - Install tensorflow-gpu
   - CUDA compatible GPU required
   - Speed: 50-100ms vs 100-300ms on CPU

2. Use lighter model
   - Currently using MobileNetV2 (lightweight)
   - MobileNetV1 is even lighter
   - ResNet50 is more accurate but heavier

3. Enable model caching
   - Model is loaded once at startup
   - Subsequent predictions use cached model

4. Optimize image upload
   - Compress images before upload
   - Use JPEG format (smaller than PNG)
   - Resize large images (224x224 optimal)

5. Use batch prediction
   - Process multiple images together
   - More efficient than individual predictions

═══════════════════════════════════════════════════════════════
"""

# Model Training Guide
TRAINING_GUIDE = """
═══════════════════════════════════════════════════════════════
🧠 MODEL TRAINING GUIDE
═══════════════════════════════════════════════════════════════

STEP 1: Download PlantVillage Dataset
─────────────────────────────────────
1. Go to: https://www.kaggle.com/datasets/emmarex/plantvillage-dataset
2. Download the dataset
3. Extract to: data/plant_images/

STEP 2: Organize Dataset
──────────────────────
data/plant_images/
├── train/
│   ├── Tomato__Early_blight/
│   │   ├── image1.jpg
│   │   ├── image2.jpg
│   │   └── ...
│   ├── Tomato__Late_blight/
│   └── ... (other diseases)
└── val/
    ├── Tomato__Early_blight/
    └── ... (other diseases)

STEP 3: Start Training
─────────────────────
cd models
python train_model.py

STEP 4: Monitor Training
────────────────────────
- Console shows accuracy & loss
- Best model auto-saved to: models/plant_disease_model.h5
- Training takes: 20-30 min (GPU) or 1-2 hours (CPU)

STEP 5: Use Trained Model
──────────────────────────
Model is automatically loaded when Flask starts

═══════════════════════════════════════════════════════════════
"""

# API Reference
API_REFERENCE = """
═══════════════════════════════════════════════════════════════
📚 API REFERENCE
═══════════════════════════════════════════════════════════════

BASE URL: http://localhost:5000

ENDPOINTS:

1. GET /
   Description: API info
   Response: {"message": "Crop Disease Detection API", "version": "1.0"}

2. GET /health
   Description: Check API and model status
   Response: {"status": "healthy", "model": "loaded"}

3. POST /predict
   Description: Predict disease from image
   Parameters: 
     - image (file): Plant leaf image
   Response: 
     {
       "success": true,
       "prediction": {
         "disease": string,
         "confidence": float (0-100),
         "cause": string,
         "treatment": string,
         "organic_alternative": string,
         "prevention": string
       },
       "image_uploaded": string (path)
     }

4. GET /diseases
   Description: List all diseases
   Response: 
     {
       "diseases": [
         {"id": 1, "name": "...", "crop": "..."},
         ...
       ]
     }

5. GET /disease/<id>
   Description: Get specific disease details
   Parameters:
     - id (int): Disease ID
   Response:
     {
       "id": 1,
       "name": "...",
       "crop": "...",
       "cause": "...",
       "treatment": "...",
       "organic_alternative": "...",
       "prevention": "..."
     }

6. POST /load-model
   Description: Load model from custom path
   Parameters:
     - model_path (string): Path to .h5 model file
   Response: {"message": "Model loaded successfully"}

═══════════════════════════════════════════════════════════════
"""

def main():
    """Display testing and demo guide"""
    print(QUICK_START)
    print(DIR_STRUCTURE)
    print(TESTING_GUIDE)
    print(TROUBLESHOOTING)
    print(PERFORMANCE_TIPS)
    print(TRAINING_GUIDE)
    print(API_REFERENCE)
    
    print("\n" + "=" * 60)
    print("For detailed information, see README.md")
    print("=" * 60)

if __name__ == '__main__':
    main()
