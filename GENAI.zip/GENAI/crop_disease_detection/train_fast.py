"""
Fast transfer learning model for crop disease detection
Uses MobileNetV2 for quick training and excellent accuracy
"""

import os
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from PIL import Image, ImageDraw, ImageFilter
import random

IMG_SIZE = 224
BATCH_SIZE = 32
EPOCHS = 15
MODEL_SAVE_PATH = 'models/plant_disease_model.h5'

CLASS_NAMES = [
    'Tomato__Early_blight',
    'Tomato__Late_blight',
    'Tomato__Septoria_leaf_spot',
    'Tomato__Bacterial_speck',
    'Tomato__Powdery_mildew',
    'Tomato__Yellow_leaf_curl_virus',
    'Potato__Early_blight',
    'Potato__Late_blight',
    'Potato__Leaf_scorch',
    'Corn__Northern_leaf_blight',
    'Corn__Gray_leaf_spot',
    'Healthy'
]

def create_synthetic_leaf(disease_type, size=224):
    """Create synthetic leaf image with disease characteristics"""
    img = Image.new('RGB', (size, size), color=(255, 255, 255))
    draw = ImageDraw.Draw(img)
    
    # Base leaf color
    leaf_colors = {
        'Tomato__Early_blight': (34, 139, 34),
        'Tomato__Late_blight': (46, 125, 50),
        'Tomato__Septoria_leaf_spot': (56, 142, 60),
        'Tomato__Bacterial_speck': (76, 175, 80),
        'Tomato__Powdery_mildew': (129, 199, 132),
        'Tomato__Yellow_leaf_curl_virus': (205, 220, 57),
        'Potato__Early_blight': (27, 94, 32),
        'Potato__Late_blight': (51, 102, 51),
        'Potato__Leaf_scorch': (85, 107, 47),
        'Corn__Northern_leaf_blight': (139, 195, 74),
        'Corn__Gray_leaf_spot': (165, 214, 167),
        'Healthy': (76, 175, 80)
    }
    
    leaf_color = leaf_colors.get(disease_type, (76, 175, 80))
    
    # Draw leaf shape
    margin = size // 4
    draw.ellipse([margin, margin // 2, size - margin, size - margin // 2], 
                 fill=leaf_color, outline=(0, 100, 0), width=3)
    
    # Add disease markings
    if 'Early_blight' in disease_type or 'Late_blight' in disease_type:
        for _ in range(random.randint(8, 15)):
            x = random.randint(margin, size - margin)
            y = random.randint(size // 4, 3 * size // 4)
            radius = random.randint(8, 20)
            draw.ellipse([x - radius, y - radius, x + radius, y + radius],
                        fill=(139, 69, 19), outline=(101, 50, 15), width=2)
    elif 'Septoria' in disease_type:
        for _ in range(random.randint(15, 25)):
            x = random.randint(margin, size - margin)
            y = random.randint(size // 4, 3 * size // 4)
            radius = random.randint(4, 8)
            draw.ellipse([x - radius, y - radius, x + radius, y + radius],
                        fill=(110, 40, 40), outline=(60, 20, 20), width=1)
    elif 'Bacterial_speck' in disease_type:
        for _ in range(random.randint(20, 35)):
            x = random.randint(margin, size - margin)
            y = random.randint(size // 4, 3 * size // 4)
            radius = random.randint(2, 4)
            draw.ellipse([x - radius, y - radius, x + radius, y + radius],
                        fill=(50, 20, 20))
    elif 'Powdery_mildew' in disease_type:
        for _ in range(random.randint(50, 80)):
            x = random.randint(margin, size - margin)
            y = random.randint(size // 4, 3 * size // 4)
            radius = random.randint(2, 5)
            draw.ellipse([x - radius, y - radius, x + radius, y + radius],
                        fill=(240, 240, 240))
    elif 'Yellow_leaf_curl_virus' in disease_type:
        for _ in range(random.randint(10, 20)):
            x = random.randint(margin, size - margin)
            y = random.randint(size // 4, 3 * size // 4)
            radius = random.randint(3, 6)
            draw.ellipse([x - radius, y - radius, x + radius, y + radius],
                        fill=(255, 255, 100))
    elif 'Leaf_scorch' in disease_type or 'Northern_leaf_blight' in disease_type:
        for _ in range(random.randint(5, 12)):
            x = random.randint(margin, size - margin)
            y = random.randint(size // 4, 3 * size // 4)
            radius = random.randint(8, 15)
            draw.ellipse([x - radius, y - radius, x + radius, y + radius],
                        fill=(128, 128, 128), outline=(64, 64, 64), width=2)
    elif 'Gray_leaf_spot' in disease_type:
        for _ in range(random.randint(15, 30)):
            x = random.randint(margin, size - margin)
            y = random.randint(size // 4, 3 * size // 4)
            radius = random.randint(4, 8)
            draw.ellipse([x - radius, y - radius, x + radius, y + radius],
                        fill=(169, 169, 169), outline=(128, 128, 128), width=1)
    
    img = img.filter(ImageFilter.GaussianBlur(radius=0.5))
    return np.array(img)

def generate_synthetic_dataset(num_samples_per_class=80):
    """Generate synthetic dataset"""
    print("\n" + "="*70)
    print(f"GENERATING SYNTHETIC DATASET ({num_samples_per_class} samples per class)")
    print("="*70 + "\n")
    
    X = []
    y = []
    
    for class_idx, class_name in enumerate(CLASS_NAMES):
        print(f"Generating {class_name}...", end=" ", flush=True)
        for _ in range(num_samples_per_class):
            img_array = create_synthetic_leaf(class_name, IMG_SIZE)
            img_array = img_array.astype('float32') / 255.0
            X.append(img_array)
            y.append(class_idx)
        print(f"✓")
    
    X = np.array(X)
    y = np.array(y)
    print(f"\nDataset: X={X.shape}, y={y.shape}")
    return X, y

def create_transfer_model():
    """Create model using MobileNetV2 transfer learning"""
    print("\n" + "="*70)
    print("CREATING TRANSFER LEARNING MODEL (MobileNetV2)")
    print("="*70 + "\n")
    
    # Load MobileNetV2 with imagenet weights
    base_model = tf.keras.applications.MobileNetV2(
        input_shape=(IMG_SIZE, IMG_SIZE, 3),
        include_top=False,
        weights='imagenet'
    )
    
    # Freeze base model layers
    base_model.trainable = True
    # Only train last few layers
    for layer in base_model.layers[:-50]:
        layer.trainable = False
    
    # Create model
    model = tf.keras.Sequential([
        tf.keras.layers.Input(shape=(IMG_SIZE, IMG_SIZE, 3)),
        tf.keras.layers.Rescaling(1./127.5, offset=-1),
        base_model,
        tf.keras.layers.GlobalAveragePooling2D(),
        tf.keras.layers.Dense(256, activation='relu'),
        tf.keras.layers.Dropout(0.5),
        tf.keras.layers.Dense(len(CLASS_NAMES), activation='softmax')
    ])
    
    return model

def main():
    print("\n")
    print("*" * 70)
    print("FAST TRANSFER LEARNING MODEL TRAINING")
    print("*" * 70)
    
    # Generate dataset
    X, y = generate_synthetic_dataset(num_samples_per_class=80)
    
    # Split
    split_idx = int(0.85 * len(X))
    indices = np.random.permutation(len(X))
    
    X_train = X[indices[:split_idx]]
    y_train = y[indices[:split_idx]]
    X_val = X[indices[split_idx:]]
    y_val = y[indices[split_idx:]]
    
    print(f"\nTrain: {X_train.shape}, Validation: {X_val.shape}")
    
    # Create model
    model = create_transfer_model()
    
    print("\nCompiling model...")
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=0.0001),
        loss='sparse_categorical_crossentropy',
        metrics=['accuracy']
    )
    
    # Train
    print("\n" + "="*70)
    print(f"TRAINING FOR {EPOCHS} EPOCHS")
    print("="*70 + "\n")
    
    callbacks = [
        tf.keras.callbacks.EarlyStopping(
            monitor='val_loss',
            patience=3,
            restore_best_weights=True
        ),
        tf.keras.callbacks.ReduceLROnPlateau(
            monitor='val_loss',
            factor=0.5,
            patience=2,
            min_lr=1e-7,
            verbose=1
        )
    ]
    
    history = model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val),
        batch_size=BATCH_SIZE,
        epochs=EPOCHS,
        callbacks=callbacks,
        verbose=1
    )
    
    # Evaluate
    print("\n" + "="*70)
    print("EVALUATION")
    print("="*70 + "\n")
    
    val_loss, val_accuracy = model.evaluate(X_val, y_val, verbose=0)
    print(f"✓ Validation Accuracy: {val_accuracy*100:.2f}%")
    print(f"✓ Validation Loss: {val_loss:.4f}")
    
    # Save
    os.makedirs(os.path.dirname(MODEL_SAVE_PATH), exist_ok=True)
    model.save(MODEL_SAVE_PATH)
    print(f"\n✓ Model saved to {MODEL_SAVE_PATH}")
    print(f"  File size: {os.path.getsize(MODEL_SAVE_PATH) / 1024 / 1024:.2f} MB")
    
    print("\n" + "*" * 70)
    print("TRAINING COMPLETE!")
    print("*" * 70 + "\n")

if __name__ == '__main__':
    main()
