"""
Model training script for Plant Disease Detection using PlantVillage Dataset
Uses MobileNetV2 for fast, lightweight training and inference
"""

import os
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D, Dropout
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau, ModelCheckpoint
import matplotlib.pyplot as plt

# Configuration
IMG_SIZE = 224
BATCH_SIZE = 32
EPOCHS = 20
LEARNING_RATE = 0.001
DATASET_PATH = 'data/plant_images'  # Update this path to your PlantVillage dataset
MODEL_SAVE_PATH = 'models/plant_disease_model.h5'

# Class mapping
CLASS_NAMES = [
    'Tomato__Early_blight',
    'Tomato__Late_blight',
    'Tomato__Septoria_leaf_spot',
    'Tomato__Bacterial_speck',
    'Tomato__Powdery_mildew',
    'Tomato__Yellow_leaf_curl_virus',
    'Potato__Early_blight',
    'Potato__Late_blight',
    'Potato__Leaf_scorch',
    'Corn__Northern_leaf_blight',
    'Corn__Gray_leaf_spot',
    'Healthy'
]

def create_model(num_classes):
    """Create MobileNetV2-based model for disease detection"""
    # Load pre-trained MobileNetV2
    base_model = MobileNetV2(
        input_shape=(IMG_SIZE, IMG_SIZE, 3),
        include_top=False,
        weights='imagenet'
    )
    
    # Freeze base model layers
    base_model.trainable = False
    
    # Add custom layers on top
    model = tf.keras.Sequential([
        base_model,
        GlobalAveragePooling2D(),
        Dense(256, activation='relu'),
        Dropout(0.5),
        Dense(128, activation='relu'),
        Dropout(0.3),
        Dense(num_classes, activation='softmax')
    ])
    
    return model, base_model

def compile_model(model, learning_rate=LEARNING_RATE):
    """Compile model with optimizer and loss"""
    optimizer = Adam(learning_rate=learning_rate)
    model.compile(
        optimizer=optimizer,
        loss='categorical_crossentropy',
        metrics=['accuracy']
    )
    return model

def prepare_data_generators():
    """Create data generators for training and validation"""
    train_datagen = ImageDataGenerator(
        rescale=1./255,
        rotation_range=20,
        width_shift_range=0.2,
        height_shift_range=0.2,
        shear_range=0.2,
        zoom_range=0.2,
        horizontal_flip=True,
        fill_mode='nearest'
    )
    
    val_datagen = ImageDataGenerator(rescale=1./255)
    
    return train_datagen, val_datagen

def load_and_prepare_data(train_datagen, val_datagen):
    """Load data from directory structure"""
    try:
        train_generator = train_datagen.flow_from_directory(
            os.path.join(DATASET_PATH, 'train'),
            target_size=(IMG_SIZE, IMG_SIZE),
            batch_size=BATCH_SIZE,
            class_mode='categorical'
        )
        
        validation_generator = val_datagen.flow_from_directory(
            os.path.join(DATASET_PATH, 'val'),
            target_size=(IMG_SIZE, IMG_SIZE),
            batch_size=BATCH_SIZE,
            class_mode='categorical'
        )
        
        return train_generator, validation_generator
    
    except Exception as e:
        print(f"Error loading data: {e}")
        print(f"Please ensure dataset is at: {DATASET_PATH}")
        return None, None

def train_model(model, train_generator, validation_generator):
    """Train the model"""
    callbacks = [
        EarlyStopping(
            monitor='val_loss',
            patience=5,
            restore_best_weights=True,
            verbose=1
        ),
        ReduceLROnPlateau(
            monitor='val_loss',
            factor=0.5,
            patience=3,
            min_lr=1e-7,
            verbose=1
        ),
        ModelCheckpoint(
            MODEL_SAVE_PATH,
            monitor='val_accuracy',
            save_best_only=True,
            verbose=1
        )
    ]
    
    history = model.fit(
        train_generator,
        validation_data=validation_generator,
        epochs=EPOCHS,
        callbacks=callbacks,
        verbose=1
    )
    
    return history

def unfreeze_and_finetune(model, base_model, train_generator, validation_generator):
    """Unfreeze and fine-tune base model layers"""
    print("\nUnfreezing base model for fine-tuning...")
    
    # Unfreeze last 50 layers
    for layer in base_model.layers[-50:]:
        layer.trainable = True
    
    # Recompile with lower learning rate
    model = compile_model(model, learning_rate=LEARNING_RATE / 10)
    
    callbacks = [
        EarlyStopping(
            monitor='val_loss',
            patience=3,
            restore_best_weights=True,
            verbose=1
        ),
        ModelCheckpoint(
            MODEL_SAVE_PATH,
            monitor='val_accuracy',
            save_best_only=True,
            verbose=1
        )
    ]
    
    history = model.fit(
        train_generator,
        validation_data=validation_generator,
        epochs=10,  # Fine-tune for fewer epochs
        callbacks=callbacks,
        verbose=1
    )
    
    return history

def evaluate_model(model, validation_generator):
    """Evaluate model on validation set"""
    loss, accuracy = model.evaluate(validation_generator)
    print(f"\nValidation Loss: {loss:.4f}")
    print(f"Validation Accuracy: {accuracy:.4f}")
    return loss, accuracy

def main():
    """Main training pipeline"""
    print("=" * 50)
    print("Plant Disease Detection Model Training")
    print("=" * 50)
    
    # Create models directory if needed
    os.makedirs('models', exist_ok=True)
    
    # Check if dataset exists
    if not os.path.exists(DATASET_PATH):
        print(f"\n⚠️  Dataset not found at: {DATASET_PATH}")
        print("\nTo train the model, follow these steps:")
        print("1. Download PlantVillage dataset from: https://www.kaggle.com/datasets/emmarex/plantvillage-dataset")
        print("2. Extract to: data/plant_images/")
        print("3. Organize into train/val folders with class subfolders")
        print("\nFolder structure should be:")
        print("data/plant_images/")
        print("├── train/")
        print("│   ├── Tomato__Early_blight/")
        print("│   ├── Tomato__Late_blight/")
        print("│   └── ... (other classes)")
        print("└── val/")
        print("    ├── Tomato__Early_blight/")
        print("    └── ... (other classes)")
        return
    
    print("\n📊 Creating model architecture...")
    model, base_model = create_model(num_classes=len(CLASS_NAMES))
    model = compile_model(model)
    
    print(f"\nModel created with {model.count_params():,} parameters")
    model.summary()
    
    print("\n📁 Loading data...")
    train_datagen, val_datagen = prepare_data_generators()
    train_generator, validation_generator = load_and_prepare_data(train_datagen, val_datagen)
    
    if train_generator is None:
        return
    
    print(f"\nTraining samples: {train_generator.samples}")
    print(f"Validation samples: {validation_generator.samples}")
    print(f"Classes: {list(train_generator.class_indices.keys())}")
    
    print("\n🚀 Starting initial training...")
    history = train_model(model, train_generator, validation_generator)
    
    print("\n🔧 Fine-tuning base model...")
    history_finetune = unfreeze_and_finetune(model, base_model, train_generator, validation_generator)
    
    print("\n📈 Evaluating model...")
    evaluate_model(model, validation_generator)
    
    print(f"\n✅ Model saved to: {MODEL_SAVE_PATH}")
    print("\nTraining complete! You can now use this model for predictions.")

if __name__ == '__main__':
    main()
