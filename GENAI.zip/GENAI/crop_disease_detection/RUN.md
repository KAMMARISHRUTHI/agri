# 🚀 How to Run - Crop Disease Detection v3.0

## ⚡ Quick Start (3 Simple Steps)

### Step 1: Open PowerShell Terminal 1 - START BACKEND

```powershell
cd c:\Users\priya\Downloads\GENAI\crop_disease_detection\backend
python app.py
```

**Expected Output:**
```
🌾 CROP DISEASE DETECTION API - v3.0
✓ Using Real Pre-trained AI Models
✓ EfficientNetB0 + Fallback Classifier
✓ Accurate plant disease detection
```

Keep this terminal open.

---

### Step 2: Open PowerShell Terminal 2 - START FRONTEND

```powershell
cd c:\Users\priya\Downloads\GENAI\crop_disease_detection
python -m http.server 8000 --directory frontend
```

**Expected Output:**
```
Serving HTTP on :: port 8000 (http://[::]:8000/) ...
```

Keep this terminal open.

---

### Step 3: Open Browser

Click link or type in address bar:
```
http://localhost:8000
```

✅ **DONE! System is running!**

---

## 📱 How to Use the App

### Fill the Form
1. Select **Crop Type**: Tomato / Potato / Corn
2. Select **Weather**: Sunny & Dry / Rainy & Humid
3. Select **Soil Type**: Clay / Sandy
4. Select **Growth Stage**: Seedling / Mature

### Upload Plant Image (Pick One)
- **Option A**: Click on the upload box → Select image
- **Option B**: Click "Select Image" button → Select image
- **Option C**: Drag & drop image onto upload box

### Analyze
- Click **"Analyze"** button
- Wait for analysis...
- See disease diagnosis + treatment info!

---

## 🎯 What the System Does

- Analyzes uploaded plant leaf image
- Detects 12 different crop diseases
- Shows confidence level
- Provides treatment recommendations
- Suggests prevention strategies

**Supported Crops:**
- 🍅 Tomato (6 diseases)
- 🥔 Potato (3 diseases)
- 🌽 Corn (2 diseases)
- ✅ Healthy status

---

## 🛑 Troubleshooting

### Backend won't start?
```powershell
# Kill all Python processes
Get-Process python | Stop-Process -Force

# Wait 2 seconds, then restart
Start-Sleep -Seconds 2
cd c:\Users\priya\Downloads\GENAI\crop_disease_detection\backend
python app.py
```

### Frontend won't start?
```powershell
# Kill all Python processes
Get-Process python | Stop-Process -Force

# Wait 2 seconds, then restart
Start-Sleep -Seconds 2
cd c:\Users\priya\Downloads\GENAI\crop_disease_detection
python -m http.server 8000 --directory frontend
```

### Can't access http://localhost:8000?
- Check that frontend server is running (Terminal 2)
- Try refreshing browser (Ctrl+R)
- Check if port 8000 is in use
- Try http://127.0.0.1:8000 instead

### Predictions not working?
- Verify backend is running (Terminal 1)
- Check F12 browser console for errors
- Try uploading a different image
- Make sure image is PNG, JPG, or GIF

### Image upload not working?
- Try clicking different part of upload box
- Try "Select Image" button
- Try drag & drop method
- Ensure image is < 16 MB

---

## 📊 System Architecture

```
┌─────────────────────────────────────┐
│   Browser (port 8000)               │
│   - index.html (upload form)        │
│   - results.html (show results)     │
└──────────────┬──────────────────────┘
               │ (HTTP requests)
               ↓
┌─────────────────────────────────────┐
│   Flask API (port 5000)             │
│   - EfficientNetB0 AI model         │
│   - Color-based fallback            │
│   - Disease mapping                 │
└──────────────┬──────────────────────┘
               │ (JSON responses)
               ↓
┌─────────────────────────────────────┐
│   Database                          │
│   - disease_database.json           │
│   - 12 diseases with full info      │
└─────────────────────────────────────┘
```

---

## 📁 Project Files

```
crop_disease_detection/
├── backend/
│   └── app.py                    ← Main API server
├── frontend/
│   ├── index.html                ← Upload page
│   └── results.html              ← Results page
├── data/
│   └── disease_database.json     ← Disease information
├── models/
│   └── plant_disease_model.h5    ← Legacy model (not used)
└── RUN.md                        ← This file
```

---

## 💡 Tips

✅ Keep both terminals open while using the app
✅ Upload clear, well-lit photos of leaves
✅ Try uploading different plant types to test
✅ Check disease information on results page
✅ Press F12 in browser to see detailed logs

---

## 🎉 You're All Set!

Start with **Step 1, Step 2, Step 3** above and enjoy using the app! 🌿
