"""
Improved Quick Model Training - Better architecture for disease detection
Creates a more accurate model without requiring internet
"""

import os
import numpy as np
import tensorflow as tf
from PIL import Image, ImageDraw, ImageFilter
import random
from pathlib import Path

IMG_SIZE = 224
BATCH_SIZE = 16
EPOCHS = 25
MODEL_SAVE_PATH = 'models/plant_disease_model.h5'

CLASS_NAMES = [
    'Tomato__Early_blight',
    'Tomato__Late_blight',
    'Tomato__Septoria_leaf_spot',
    'Tomato__Bacterial_speck',
    'Tomato__Powdery_mildew',
    'Tomato__Yellow_leaf_curl_virus',
    'Potato__Early_blight',
    'Potato__Late_blight',
    'Potato__Leaf_scorch',
    'Corn__Northern_leaf_blight',
    'Corn__Gray_leaf_spot',
    'Healthy'
]

def generate_realistic_leaf_image(disease_class, size=IMG_SIZE, variation=0):
    """Generate more realistic leaf images for training"""
    # Create base green leaf with natural color variation
    img = Image.new('RGB', (size, size), (40, 140, 40))
    draw = ImageDraw.Draw(img, 'RGBA')
    
    # Add natural texture
    pixels = img.load()
    for i in range(size):
        for j in range(size):
            if random.random() < 0.3:  # 30% texture variation
                r, g, b = pixels[i, j]
                var = random.randint(-15, 15)
                r = max(0, min(255, r + var))
                g = max(0, min(255, g + var))
                b = max(0, min(255, b + var))
                pixels[i, j] = (r, g, b)
    
    # Draw main vein structure
    center_x, center_y = size // 2, size // 2
    for angle in np.linspace(0, 360, 12, endpoint=False):
        rad = np.radians(angle)
        end_x = center_x + int(size * 0.35 * np.cos(rad))
        end_y = center_y + int(size * 0.35 * np.sin(rad))
        draw.line([(center_x, center_y), (end_x, end_y)], fill=(20, 80, 20), width=3)
        
        # Add secondary veins
        for secondary_dist in [0.5, 0.7]:
            sec_x = center_x + int(size * secondary_dist * np.cos(rad))
            sec_y = center_y + int(size * secondary_dist * np.sin(rad))
            for sec_angle in np.linspace(-40, 40, 3):
                sec_rad = np.radians(angle + sec_angle)
                sec_end_x = sec_x + int(size * 0.15 * np.cos(sec_rad))
                sec_end_y = sec_y + int(size * 0.15 * np.sin(sec_rad))
                draw.line([(sec_x, sec_y), (sec_end_x, sec_end_y)], fill=(25, 90, 25), width=1)
    
    # Add disease-specific patterns
    if 'Early_blight' in disease_class:
        # Characteristic concentric rings of early blight
        num_spots = 6 + variation % 3
        for _ in range(num_spots):
            x = random.randint(40, size-40)
            y = random.randint(40, size-40)
            # Outer brown ring
            draw.ellipse([x-30, y-30, x+30, y+30], fill=(139, 69, 19, 120))
            # Inner darker center
            draw.ellipse([x-20, y-20, x+20, y+20], fill=(100, 50, 10, 150))
            # Target pattern
            draw.ellipse([x-10, y-10, x+10, y+10], fill=(160, 82, 45, 200))
    
    elif 'Late_blight' in disease_class:
        # Water-soaked, irregular patches
        num_spots = 8 + variation % 4
        for _ in range(num_spots):
            x = random.randint(30, size-30)
            y = random.randint(30, size-30)
            # Irregular water-soaked appearance
            draw.ellipse([x-20, y-25, x+20, y+25], fill=(60, 60, 60, 140))
            draw.ellipse([x-15, y-18, x+15, y+18], fill=(45, 45, 45, 180))
    
    elif 'Powdery_mildew' in disease_class:
        # White fuzzy coating
        for x in range(0, size, 25):
            for y in range(0, size, 25):
                if random.random() > 0.2:
                    # White powder effect
                    for _ in range(random.randint(3, 8)):
                        px = x + random.randint(-12, 12)
                        py = y + random.randint(-12, 12)
                        draw.ellipse([px-3, py-3, px+3, py+3], fill=(220, 220, 220, 80))
    
    elif 'Septoria_leaf_spot' in disease_class:
        # Small spots with yellow halos
        num_spots = 12 + variation % 5
        for _ in range(num_spots):
            x = random.randint(35, size-35)
            y = random.randint(35, size-35)
            # Yellow halo
            draw.ellipse([x-12, y-12, x+12, y+12], fill=(255, 200, 0, 150))
            # Dark center
            draw.ellipse([x-6, y-6, x+6, y+6], fill=(50, 50, 10, 200))
            draw.ellipse([x-2, y-2, x+2, y+2], fill=(0, 0, 0, 220))
    
    elif 'Bacterial_speck' in disease_class:
        # Tiny raised lesions
        num_specks = 30 + variation % 20
        for _ in range(num_specks):
            x = random.randint(20, size-20)
            y = random.randint(20, size-20)
            # Brown speck
            for i in range(random.randint(2, 4)):
                r = random.randint(100, 105)
                g = random.randint(60, 70)
                b = random.randint(25, 35)
                draw.point((x+random.randint(-1, 1), y+random.randint(-1, 1)), fill=(r, g, b))
    
    elif 'Yellow_leaf_curl_virus' in disease_class:
        # Yellow areas and curling effect
        for i in range(5):
            x1 = random.randint(20, size-50)
            y1 = random.randint(20, size-50)
            x2 = x1 + random.randint(40, 80)
            y2 = y1 + random.randint(40, 80)
            draw.ellipse([x1, y1, x2, y2], fill=(200, 200, 50, 100))
    
    elif 'Leaf_scorch' in disease_class:
        # Brown/tan edges characteristic of scorch
        draw.rectangle([0, 0, size, 25], fill=(139, 69, 19, 140))
        draw.rectangle([0, size-25, size, size], fill=(139, 69, 19, 140))
        draw.rectangle([0, 0, 25, size], fill=(139, 69, 19, 140))
        draw.rectangle([size-25, 0, size, size], fill=(139, 69, 19, 140))
        # Gradual transition
        for i in range(25, 40):
            alpha = int(140 * (40 - i) / 15)
            draw.line([(i, 0), (i, size)], fill=(139, 69, 19, alpha), width=1)
            draw.line([(size-i, 0), (size-i, size)], fill=(139, 69, 19, alpha), width=1)
    
    elif 'Northern_leaf_blight' in disease_class:
        # Long oval/eye-shaped lesions
        num_lesions = 5 + variation % 3
        for _ in range(num_lesions):
            x = random.randint(50, size-50)
            y = random.randint(40, size-40)
            # Long oval lesion
            draw.ellipse([x-28, y-12, x+28, y+12], fill=(120, 100, 80, 180))
            draw.ellipse([x-22, y-8, x+22, y+8], fill=(140, 115, 90, 200))
    
    elif 'Gray_leaf_spot' in disease_class:
        # Rectangular gray lesions
        num_spots = 8 + variation % 4
        for _ in range(num_spots):
            x = random.randint(45, size-45)
            y = random.randint(45, size-45)
            draw.rectangle([x-18, y-22, x+18, y+22], fill=(128, 128, 128, 170))
            draw.rectangle([x-12, y-16, x+12, y+16], fill=(110, 110, 110, 200))
    
    elif 'Healthy' in disease_class:
        # Add slight natural variation for healthy leaves
        for _ in range(100):
            x = random.randint(0, size)
            y = random.randint(0, size)
            # Very subtle color variation
            r, g, b = pixels[x, y] if x < size and y < size else (40, 140, 40)
            var = random.randint(-5, 5)
            r = max(0, min(255, r + var))
            g = max(0, min(255, g + var))
            b = max(0, min(255, b + var))
            if x < size and y < size:
                pixels[x, y] = (r, g, b)
    
    # Apply slight blur for realism
    img = img.filter(ImageFilter.GaussianBlur(radius=0.5))
    
    # Convert to array
    img_array = np.array(img).astype('float32') / 255.0
    return img_array

def create_synthetic_dataset(num_samples=600):
    """Create larger, more realistic synthetic training dataset"""
    print("\n" + "="*70)
    print("GENERATING REALISTIC TRAINING DATA")
    print("="*70)
    
    num_classes = len(CLASS_NAMES)
    samples_per_class = num_samples // num_classes
    
    X_train = []
    y_train = []
    X_val = []
    y_val = []
    
    for class_idx, class_name in enumerate(CLASS_NAMES):
        print(f"Generating {class_name:40} ... ", end='', flush=True)
        
        for i in range(samples_per_class):
            # Generate image with variation
            img = generate_realistic_leaf_image(class_name, variation=i)
            
            if i < samples_per_class * 0.8:  # 80% train
                X_train.append(img)
                y_train.append(class_idx)
            else:  # 20% validation
                X_val.append(img)
                y_val.append(class_idx)
        
        print(f"✓")
    
    X_train = np.array(X_train)
    y_train = np.array(y_train)
    X_val = np.array(X_val)
    y_val = np.array(y_val)
    
    # Convert labels to categorical
    y_train = tf.keras.utils.to_categorical(y_train, num_classes)
    y_val = tf.keras.utils.to_categorical(y_val, num_classes)
    
    print(f"\nTraining data: {X_train.shape}")
    print(f"Validation data: {X_val.shape}")
    
    return (X_train, y_train), (X_val, y_val)

def create_improved_model(num_classes):
    """Create improved deep CNN model"""
    print("\n" + "="*70)
    print("CREATING IMPROVED MODEL")
    print("="*70 + "\n")
    
    model = tf.keras.Sequential([
        # Block 1
        tf.keras.layers.Conv2D(32, 3, padding='same', activation='relu', 
                              input_shape=(IMG_SIZE, IMG_SIZE, 3)),
        tf.keras.layers.Conv2D(32, 3, padding='same', activation='relu'),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.MaxPooling2D(2),
        tf.keras.layers.Dropout(0.2),
        
        # Block 2
        tf.keras.layers.Conv2D(64, 3, padding='same', activation='relu'),
        tf.keras.layers.Conv2D(64, 3, padding='same', activation='relu'),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.MaxPooling2D(2),
        tf.keras.layers.Dropout(0.2),
        
        # Block 3
        tf.keras.layers.Conv2D(128, 3, padding='same', activation='relu'),
        tf.keras.layers.Conv2D(128, 3, padding='same', activation='relu'),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.MaxPooling2D(2),
        tf.keras.layers.Dropout(0.3),
        
        # Block 4
        tf.keras.layers.Conv2D(256, 3, padding='same', activation='relu'),
        tf.keras.layers.Conv2D(256, 3, padding='same', activation='relu'),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.MaxPooling2D(2),
        tf.keras.layers.Dropout(0.3),
        
        # Block 5 - Additional depth
        tf.keras.layers.Conv2D(512, 3, padding='same', activation='relu'),
        tf.keras.layers.Conv2D(512, 3, padding='same', activation='relu'),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.MaxPooling2D(2),
        tf.keras.layers.Dropout(0.4),
        
        # Dense layers
        tf.keras.layers.Flatten(),
        tf.keras.layers.Dense(512, activation='relu'),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.Dropout(0.5),
        tf.keras.layers.Dense(256, activation='relu'),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.Dropout(0.5),
        tf.keras.layers.Dense(128, activation='relu'),
        tf.keras.layers.Dropout(0.3),
        tf.keras.layers.Dense(num_classes, activation='softmax')
    ])
    
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=0.0005),
        loss='categorical_crossentropy',
        metrics=['accuracy']
    )
    
    print(f"Model created!")
    print(f"Total parameters: {model.count_params():,}")
    print(f"Output classes: {num_classes}")
    
    return model

def main():
    print("\n" + "="*80)
    print("IMPROVED MODEL TRAINING - DISEASE DETECTION")
    print("="*80)
    
    os.makedirs('models', exist_ok=True)
    
    # Create synthetic data
    (X_train, y_train), (X_val, y_val) = create_synthetic_dataset(num_samples=600)
    
    # Create model
    model = create_improved_model(len(CLASS_NAMES))
    
    # Train with data augmentation
    print("\n" + "="*70)
    print("TRAINING MODEL")
    print("="*70 + "\n")
    
    # Data augmentation
    from tensorflow.keras.preprocessing.image import ImageDataGenerator
    datagen = ImageDataGenerator(
        rotation_range=30,
        width_shift_range=0.2,
        height_shift_range=0.2,
        horizontal_flip=True,
        vertical_flip=True,
        zoom_range=0.3,
        brightness_range=[0.7, 1.3],
        fill_mode='nearest'
    )
    
    callbacks = [
        tf.keras.callbacks.EarlyStopping(
            monitor='val_loss',
            patience=4,
            restore_best_weights=True,
            verbose=1
        ),
        tf.keras.callbacks.ModelCheckpoint(
            MODEL_SAVE_PATH,
            monitor='val_accuracy',
            save_best_only=True,
            verbose=0
        ),
        tf.keras.callbacks.ReduceLROnPlateau(
            monitor='val_loss',
            factor=0.5,
            patience=3,
            min_lr=1e-7,
            verbose=1
        )
    ]
    
    history = model.fit(
        datagen.flow(X_train, y_train, batch_size=BATCH_SIZE),
        validation_data=(X_val, y_val),
        epochs=EPOCHS,
        callbacks=callbacks,
        verbose=1
    )
    
    # Save
    print(f"\n\nSaving model to {MODEL_SAVE_PATH}...")
    model.save(MODEL_SAVE_PATH)
    
    print("\n" + "="*80)
    print("✓ TRAINING COMPLETE!")
    print("="*80)
    print(f"\nModel saved: {MODEL_SAVE_PATH}")
    print(f"Classes: {len(CLASS_NAMES)}")
    print("\nTo use this model:")
    print("  1. Restart Flask: python backend/app.py")
    print("  2. Upload plant leaf images for disease detection")
    print("\n✓ Model is ready for evaluaton!")

if __name__ == '__main__':
    main()
