# 🌿 Crop Disease Detection System - User Guide

## Overview

The **Crop Disease Detection System** is an AI-powered plant health analysis platform that uses deep learning to identify crop diseases with high accuracy. The system now features an enhanced two-page workflow that captures crop context information alongside image analysis for more comprehensive recommendations.

---

## 🎯 What's New: Context-Aware Analysis

### Previous Version
- Single page interface
- Image upload only
- Generic disease information

### Current Version ✨
- **Two-page workflow** for better UX
- **Context-aware analysis** with 4 input parameters
- **Comprehensive results** page with detailed recommendations
- **Urgent warning system** for critical diseases
- **Responsive design** for all devices

---

## 📖 How to Use

### Page 1: Analysis Input

#### Step 1: Select Crop Type
- **What it is**: The type of crop you're growing
- **Why it matters**: Different crops have different disease profiles
- **Options**: Tomato, Potato, Corn, Wheat, Rice, Apple, Grape, Cucumber, Lettuce, Pepper
- **Example**: If growing tomatoes, select "Tomato"

#### Step 2: Select Weather Condition
- **What it is**: Current weather in your area
- **Why it matters**: Disease spread depends heavily on weather (humidity, temperature, moisture)
- **Options**:
  - **Sunny & Dry**: Low humidity, good for prevention
  - **Cloudy**: Moderate conditions
  - **Rainy & Humid**: High risk for fungal diseases
  - **Very Wet & High Humidity**: Critical for disease spread
  - **Hot & Dry**: Heat stress risk
  - **Cold & Damp**: Cold damage risk
  - **Moderate Temperature**: Optimal conditions
- **Example**: If it rained recently and humidity is high, select "Rainy & Humid"

#### Step 3: Select Soil Type
- **What it is**: The composition of soil in your field
- **Why it matters**: Soil type affects water retention and nutrient availability, impacting disease resistance
- **Options**:
  - **Clay (Heavy, retains moisture)**: Retains water, can cause waterlogging
  - **Sandy (Drains quickly)**: Fast drainage but less nutrient retention
  - **Loam (Well-balanced)**: Ideal soil composition
  - **Silt (Fertile, smooth)**: Good fertility
  - **Acidic Soil (pH < 6.5)**: Low pH conditions
  - **Alkaline Soil (pH > 7.5)**: High pH conditions
  - **Wet/Waterlogged**: Standing water present
- **Example**: If your soil is heavy and retains water, select "Clay"

#### Step 4: Select Growth Stage
- **What it is**: How mature your crop is
- **Why it matters**: Disease susceptibility varies by growth stage
- **Options**:
  - **Seedling (0-2 weeks)**: Just sprouted, very vulnerable
  - **Vegetative Growth (2-4 weeks)**: Growing foliage
  - **Flowering Stage**: Flowers developing
  - **Fruiting/Pod Development**: Bearing fruits/pods
  - **Mature Plant (ready to harvest)**: Nearly complete
  - **Stressed/Weak Plant**: Under stress (nutrient, water, etc.)
- **Example**: If plants are developing flowers, select "Flowering Stage"

#### Step 5: Upload Plant Image
- **How to upload**:
  - Click the upload box
  - OR drag and drop an image
  - OR click "Select Image" button
- **Requirements**:
  - Image format: PNG, JPG, JPEG, or GIF
  - Maximum size: 16MB
  - Should show affected plant leaf clearly
- **Tips**:
  - Use good lighting
  - Focus on affected area
  - Avoid blurry images

#### Step 6: Analyze
- Once all fields filled and image selected, the "🔍 Analyze Plant Health" button becomes active
- Click to start analysis
- Wait for processing (5-10 seconds typically)
- Will automatically navigate to results page

---

### Page 2: Analysis Results

#### Disease Diagnosis
Shows the identified disease with a confidence score:
```
✅ Early Blight (Tomato)
Detection Confidence: 87.5%
```

#### Context Information Display
Confirms what you input:
- 🌾 Crop Type: Tomato
- 🌤️ Weather Condition: Rainy & Humid
- 🌱 Soil Type: Clay
- 📈 Growth Stage: Mature

#### What Causes This Disease?
**Detailed scientific explanation**:
- Causative organism (fungus, bacteria, virus)
- Environmental conditions needed
- How it spreads
- Seasonal patterns

Example:
> "Fungal infection caused by Alternaria solani. This fungus thrives in warm (65-85°F), wet conditions. It primarily spreads through spores in water droplets, soil, and infected plant debris."

#### Recommended Treatment
**Chemical/Professional treatments**:
- Specific fungicides with names
- Application frequency
- Additional management practices

Example:
> "Apply Chlorothalonil, Mancozeb, or Copper sulfate every 7-10 days. Remove infected leaves immediately. Water only at soil level."

#### Organic Alternatives
**Natural, chemical-free solutions**:
- Organic products available
- Homemade recipes
- Application rates

Example:
> "Neem oil spray (5% solution) every 7-10 days. Potassium bicarbonate spray weekly. Mix 1 tbsp baking soda + 1 tbsp horticultural oil per gallon water."

#### Prevention Tips
**How to prevent future outbreaks**:
- Spacing recommendations
- Watering methods
- Crop rotation practices
- Sanitation procedures

Example:
> "Space plants 24-36 inches apart for airflow. Remove lower leaves (up to 12 inches from soil) as preventive. Use drip irrigation, avoid overhead watering."

#### Additional Information
- **👀 Visible Symptoms**: What to look for
- **⚠️ Severity Level**: How serious (Low/Medium/High/CRITICAL)
- **📈 Spread Rate**: How fast it spreads

#### Urgent Warning
If disease is critical:
```
🚨 URGENT: This disease is CRITICAL and can cause severe damage. 
Immediate action required!
```

---

## 🎨 Understanding the UI

### Form Layout
- **Crop Type & Weather**: Top row
- **Soil Type & Growth Stage**: Second row
- **Divider line**: Visual separation
- **Image Upload Section**: Separate highlighted section
- **Analyze Button**: Full width, prominent

### Results Layout
- **Header**: Disease name with confidence bar
- **Context Box**: Your input information
- **Information Sections**: Organized with icons
  - 🦠 What Causes
  - 💊 Treatment
  - 🌿 Organic
  - 🛡️ Prevention
  - 👀 Symptoms
  - ⚠️ Severity & 📈 Spread Rate

### Colors Meaning
- **Blue/Purple**: Primary action colors
- **Red/Pink**: Urgent/analyze button
- **Yellow**: Warning information
- **Red (dark)**: Critical/urgent alerts

---

## ✨ Smart Features

### 1. Form Validation
- All 4 context fields required
- Image must be selected
- "Analyze" button only enabled when complete
- Clear error messages if validation fails

### 2. Image Validation
System checks:
- ✅ File exists
- ✅ Correct file type (PNG, JPG, GIF)
- ✅ File size under 16MB
- ✅ Image is valid and readable

### 3. Confidence Scoring
- Shows AI model's certainty (0-100%)
- Animated progress bar
- Helps evaluate result reliability

### 4. Urgent Detection
- Automatically detects critical diseases
- Shows 🚨 warning if severity is CRITICAL
- Suggests immediate action

### 5. Context-Aware Info
- Results consider your input parameters
- More relevant recommendations
- Takes into account weather, soil, growth stage

---

## 📊 Example Scenarios

### Scenario 1: Tomato with Early Blight
```
Input:
- Crop: Tomato
- Weather: Rainy & Humid
- Soil: Clay
- Growth Stage: Mature
- Image: Shows circular brown spots with rings

Result:
- Disease: Early Blight (87% confidence)
- Severity: High
- Recommendation: Apply fungicides, improve air circulation
```

### Scenario 2: Potato with Late Blight
```
Input:
- Crop: Potato
- Weather: Very Wet & High Humidity
- Soil: Wet/Waterlogged
- Growth Stage: Flowering
- Image: Shows water-soaked spots

Result:
- Disease: Late Blight (92% confidence)
- Severity: CRITICAL
- Urgent Warning: Immediate action required!
- Recommendation: Apply metalaxyl immediately
```

---

## 🔧 Troubleshooting

### Problem: "Analyze" button disabled
**Solution**: Ensure all 4 dropdowns have selections AND image is uploaded

### Problem: "No image provided" error
**Solution**: Click upload box or "Select Image" button to choose file

### Problem: "Invalid file type" error
**Solution**: Use PNG, JPG, JPEG, or GIF format only

### Problem: "File size exceeds" error
**Solution**: Image larger than 16MB - use smaller image or compress it

### Problem: Results page blank
**Solution**: Try analyzing again, or refresh browser and start over

### Problem: API connection error
**Solution**: Ensure Flask backend running on port 5000

---

## 💡 Tips for Best Results

### Image Quality
- ✅ Good lighting (natural sunlight preferred)
- ✅ Clear focus on affected area
- ✅ Show both healthy and diseased parts
- ✅ Avoid shadows and glare
- ❌ Blurry images
- ❌ Too dark/bright
- ❌ Only background without plant

### Accurate Context
- Be precise with weather (check local conditions)
- Know your soil type (test kit available at garden centers)
- Count weeks since planting for growth stage
- Note any stress conditions (drought, nutrient issues)

### Interpreting Results
- Confidence score 80%+ = Very reliable
- Confidence 60-80% = Reliable but verify
- Confidence <60% = May need expert verification
- Always visually confirm diagnosis

### Follow Recommendations
- Follow treatment frequencies exactly
- Mix solutions to specified concentrations
- Apply during recommended weather
- Practice prevention for next season

---

## 📱 Using on Mobile

The system is fully responsive:
- Form fields stack vertically
- Image preview adjusts to screen
- Results readable on all sizes
- Touch-friendly buttons

---

## 🌐 System Requirements

### Browser
- Chrome 80+
- Firefox 75+
- Safari 13+
- Edge 80+

### Connection
- Internet connection (for API calls)
- Minimum 1Mbps for image upload

### Hardware
- Any modern computer or mobile device
- Sufficient storage for uploads (16MB max per image)

---

## 🔐 Privacy & Data

- ✅ Uploaded images processed locally
- ✅ No data stored permanently
- ✅ Sessions cleared on page refresh
- ✅ HTTPS recommended for sensitive use
- ✅ No third-party sharing

---

## 📞 Getting Help

### For Technical Issues
1. Check browser console for errors (F12)
2. Ensure Flask backend running
3. Verify internet connection
4. Clear browser cache and retry

### For Disease Identification
1. Review "What Causes" section
2. Compare symptoms with "Visible Symptoms"
3. Verify with disease database
4. Consider consulting local agriculture expert

---

## 🎓 Learning More

The system provides:
- Scientific names of diseases
- Detailed cause explanations
- Prevention strategies
- Both chemical and organic solutions
- Severity and spread information

Use this information to:
- Understand disease mechanisms
- Plan prevention strategies
- Time treatments effectively
- Make informed farming decisions

---

## ✅ Checklist for Use

- [ ] All 4 context fields selected
- [ ] Image uploaded successfully
- [ ] Image shows plant with clear detail
- [ ] Weather info is current and accurate
- [ ] Growth stage carefully selected
- [ ] Click "Analyze Plant Health"
- [ ] Review all results information
- [ ] Note treatment recommendations
- [ ] Plan next steps based on results

---

**System Ready for Use! 🌿**

Start by visiting: **http://localhost:8000**
