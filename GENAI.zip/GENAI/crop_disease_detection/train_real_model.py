"""
Download and train on real PlantVillage dataset
Uses TensorFlow Datasets to get actual plant disease images
"""

import os
import tensorflow as tf
import numpy as np
from pathlib import Path
import sys

IMG_SIZE = 224
BATCH_SIZE = 32
EPOCHS = 15
MODEL_SAVE_PATH = 'models/plant_disease_model.h5'

CLASS_NAMES = [
    'Tomato__Early_blight',
    'Tomato__Late_blight',
    'Tomato__Septoria_leaf_spot',
    'Tomato__Bacterial_speck',
    'Tomato__Powdery_mildew',
    'Tomato__Yellow_leaf_curl_virus',
    'Potato__Early_blight',
    'Potato__Late_blight',
    'Potato__Leaf_scorch',
    'Corn__Northern_leaf_blight',
    'Corn__Gray_leaf_spot',
    'Healthy'
]

def download_real_dataset():
    """Download real PlantVillage dataset from TensorFlow Datasets"""
    print("\n" + "="*70)
    print("DOWNLOADING REAL PLANTVILLAGE DATASET")
    print("="*70)
    print("Downloading actual plant disease images...")
    print("This may take 5-15 minutes depending on internet speed\n")
    
    try:
        # Try to import tensorflow_datasets
        try:
            import tensorflow_datasets as tfds
        except ImportError:
            print("Installing tensorflow-datasets...")
            os.system(f"{sys.executable} -m pip install tensorflow-datasets -q")
            import tensorflow_datasets as tfds
        
        # Download PlantVillage dataset
        print("Loading PlantVillage dataset...")
        ds, info = tfds.load(
            'plant_village',
            split=['train[:80%]', 'train[80%:]'],
            with_info=True,
            download=True,
            data_dir='./datasets'
        )
        
        train_ds, val_ds = ds
        
        print(f"✓ Dataset loaded successfully!")
        print(f"  Total samples: {info.splits['train'].num_examples}")
        
        return train_ds, val_ds, info
    
    except Exception as e:
        print(f"Error downloading dataset: {e}")
        print("\nTrying alternative approach - using local cached data...")
        return None, None, None

def prepare_dataset(train_ds, val_ds):
    """Prepare dataset for training"""
    print("\n" + "="*70)
    print("PREPARING DATASET")
    print("="*70 + "\n")
    
    def preprocess(image, label):
        # Resize image
        image = tf.image.resize(image, (IMG_SIZE, IMG_SIZE))
        # Normalize to [0, 1]
        image = image / 255.0
        # Convert label to one-hot
        label = tf.one_hot(label, len(CLASS_NAMES))
        return image, label
    
    # Apply preprocessing
    train_prepared = train_ds.map(preprocess, num_parallel_calls=tf.data.AUTOTUNE)
    train_prepared = train_prepared.batch(BATCH_SIZE)
    train_prepared = train_prepared.prefetch(tf.data.AUTOTUNE)
    
    val_prepared = val_ds.map(preprocess, num_parallel_calls=tf.data.AUTOTUNE)
    val_prepared = val_prepared.batch(BATCH_SIZE)
    val_prepared = val_prepared.prefetch(tf.data.AUTOTUNE)
    
    print("Dataset prepared successfully!")
    return train_prepared, val_prepared

def create_model():
    """Create efficient model without requiring pre-trained weights"""
    print("\n" + "="*70)
    print("CREATING MODEL ARCHITECTURE")
    print("="*70 + "\n")
    
    # Build a custom CNN model that doesn't require downloading weights
    model = tf.keras.Sequential([
        # Block 1
        tf.keras.layers.Conv2D(64, 3, padding='same', activation='relu', 
                              input_shape=(IMG_SIZE, IMG_SIZE, 3)),
        tf.keras.layers.Conv2D(64, 3, padding='same', activation='relu'),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.MaxPooling2D(2),
        tf.keras.layers.Dropout(0.25),
        
        # Block 2
        tf.keras.layers.Conv2D(128, 3, padding='same', activation='relu'),
        tf.keras.layers.Conv2D(128, 3, padding='same', activation='relu'),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.MaxPooling2D(2),
        tf.keras.layers.Dropout(0.25),
        
        # Block 3
        tf.keras.layers.Conv2D(256, 3, padding='same', activation='relu'),
        tf.keras.layers.Conv2D(256, 3, padding='same', activation='relu'),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.MaxPooling2D(2),
        tf.keras.layers.Dropout(0.25),
        
        # Block 4
        tf.keras.layers.Conv2D(512, 3, padding='same', activation='relu'),
        tf.keras.layers.Conv2D(512, 3, padding='same', activation='relu'),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.MaxPooling2D(2),
        tf.keras.layers.Dropout(0.25),
        
        # Dense layers
        tf.keras.layers.Flatten(),
        tf.keras.layers.Dense(512, activation='relu'),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.Dropout(0.5),
        tf.keras.layers.Dense(256, activation='relu'),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.Dropout(0.5),
        tf.keras.layers.Dense(len(CLASS_NAMES), activation='softmax')
    ])
    
    # Compile
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
        loss='categorical_crossentropy',
        metrics=['accuracy']
    )
    
    print(f"Model created!")
    print(f"Total parameters: {model.count_params():,}")
    print(f"Output classes: {len(CLASS_NAMES)}")
    
    return model

def train_model(model, train_ds, val_ds):
    """Train the model"""
    print("\n" + "="*70)
    print("TRAINING MODEL ON REAL PLANT DISEASE IMAGES")
    print("="*70 + "\n")
    
    callbacks = [
        tf.keras.callbacks.EarlyStopping(
            monitor='val_loss',
            patience=3,
            restore_best_weights=True,
            verbose=1
        ),
        tf.keras.callbacks.ReduceLROnPlateau(
            monitor='val_loss',
            factor=0.5,
            patience=2,
            min_lr=1e-7,
            verbose=1
        ),
        tf.keras.callbacks.ModelCheckpoint(
            MODEL_SAVE_PATH,
            monitor='val_accuracy',
            save_best_only=True,
            verbose=0
        )
    ]
    
    history = model.fit(
        train_ds,
        validation_data=val_ds,
        epochs=EPOCHS,
        callbacks=callbacks,
        verbose=1
    )
    
    return history

def main():
    print("\n" + "="*80)
    print("PLANT DISEASE DETECTION - REAL DATASET TRAINING")
    print("="*80)
    
    os.makedirs('models', exist_ok=True)
    
    # Download real dataset
    train_ds, val_ds, info = download_real_dataset()
    
    if train_ds is None:
        print("\n⚠️  Could not download PlantVillage dataset")
        print("Please check your internet connection and try again")
        print("\nAlternatively, run: python quick_train.py for demo mode")
        return
    
    # Prepare data
    train_prepared, val_prepared = prepare_dataset(train_ds, val_ds)
    
    # Create model
    model = create_model()
    
    # Train
    history = train_model(model, train_prepared, val_prepared)
    
    # Save
    print(f"\n\nSaving model to {MODEL_SAVE_PATH}...")
    model.save(MODEL_SAVE_PATH)
    
    print("\n" + "="*80)
    print("✓ TRAINING COMPLETE!")
    print("="*80)
    print(f"\nModel saved: {MODEL_SAVE_PATH}")
    print(f"Trained on: REAL PlantVillage dataset with {len(CLASS_NAMES)} disease classes")
    print("\nRestart Flask to use the new model:")
    print("  python backend/app.py")
    print("\nYour system will now accurately detect crop diseases!")

if __name__ == '__main__':
    main()
