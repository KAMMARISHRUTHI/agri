"""
Simple inference script for quick model testing
"""

import os
import json
import numpy as np
from PIL import Image
import tensorflow as tf
from tensorflow.keras.preprocessing import image as keras_image

# Configuration
MODEL_PATH = 'models/plant_disease_model.h5'
DISEASE_DB_PATH = 'data/disease_database.json'
IMG_SIZE = 224

# Class mapping
DISEASE_INDEX = {
    0: "Tomato__Early_blight",
    1: "Tomato__Late_blight",
    2: "Tomato__Septoria_leaf_spot",
    3: "Tomato__Bacterial_speck",
    4: "Tomato__Powdery_mildew",
    5: "Tomato__Yellow_leaf_curl_virus",
    6: "Potato__Early_blight",
    7: "Potato__Late_blight",
    8: "Potato__Leaf_scorch",
    9: "Corn__Northern_leaf_blight",
    10: "Corn__Gray_leaf_spot",
    11: "Healthy"
}

def load_model():
    """Load pre-trained model"""
    if not os.path.exists(MODEL_PATH):
        print(f"Model not found at {MODEL_PATH}")
        print("Train model first using: python models/train_model.py")
        return None
    
    try:
        model = tf.keras.models.load_model(MODEL_PATH)
        print(f"✅ Model loaded from {MODEL_PATH}")
        return model
    except Exception as e:
        print(f"❌ Error loading model: {e}")
        return None

def load_disease_db():
    """Load disease database"""
    try:
        with open(DISEASE_DB_PATH, 'r') as f:
            return json.load(f)
    except Exception as e:
        print(f"❌ Error loading disease database: {e}")
        return None

def preprocess_image(image_path):
    """Preprocess image for prediction"""
    try:
        img = keras_image.load_img(image_path, target_size=(IMG_SIZE, IMG_SIZE))
        img_array = keras_image.img_to_array(img)
        img_array = np.expand_dims(img_array, axis=0)
        img_array = img_array / 255.0
        return img_array
    except Exception as e:
        print(f"❌ Error processing image: {e}")
        return None

def get_disease_info(disease_name, disease_db):
    """Get disease info from database"""
    for disease in disease_db['diseases']:
        if disease_name.lower().replace('_', ' ') in disease['name'].lower():
            return disease
    return None

def predict(image_path, model, disease_db):
    """Make prediction for an image"""
    # Preprocess image
    img_array = preprocess_image(image_path)
    if img_array is None:
        return None
    
    # Make prediction
    predictions = model.predict(img_array, verbose=0)
    
    # Get top prediction
    predicted_class = np.argmax(predictions[0])
    confidence = float(predictions[0][predicted_class]) * 100
    
    disease_name = DISEASE_INDEX.get(predicted_class, "Unknown")
    disease_info = get_disease_info(disease_name, disease_db)
    
    if disease_info is None:
        disease_info = {
            "name": disease_name,
            "cause": "Unknown",
            "treatment": "Consult agronomist",
            "organic_alternative": "N/A",
            "prevention": "Monitor closely"
        }
    
    return {
        "disease": disease_info['name'],
        "confidence": round(confidence, 2),
        "cause": disease_info['cause'],
        "treatment": disease_info['treatment'],
        "organic_alternative": disease_info['organic_alternative'],
        "prevention": disease_info['prevention']
    }

def display_result(result):
    """Pretty print prediction result"""
    print("\n" + "="*60)
    print("🔍 CROP DISEASE DETECTION RESULT")
    print("="*60)
    print(f"\n✅ Disease: {result['disease']}")
    print(f"📌 Confidence: {result['confidence']}%")
    print(f"\n🦠 What Causes This Disease:")
    print(f"   {result['cause']}")
    print(f"\n💊 Recommended Treatment:")
    print(f"   {result['treatment']}")
    print(f"\n🌿 Organic Alternative:")
    print(f"   {result['organic_alternative']}")
    print(f"\n🛡️  Prevention Tips:")
    print(f"   {result['prevention']}")
    print("\n" + "="*60)

def main():
    """Main inference pipeline"""
    print("🌱 Crop Disease Detection - Inference")
    print("="*60)
    
    # Load model and database
    model = load_model()
    if model is None:
        return
    
    disease_db = load_disease_db()
    if disease_db is None:
        return
    
    print("\n📁 Usage: python infer.py <image_path>")
    print("\nExample: python infer.py uploads/tomato_leaf.jpg")
    
    # Interactive mode
    import sys
    if len(sys.argv) > 1:
        image_path = sys.argv[1]
        
        if not os.path.exists(image_path):
            print(f"❌ Image not found: {image_path}")
            return
        
        print(f"\n🔄 Processing: {image_path}")
        result = predict(image_path, model, disease_db)
        
        if result:
            display_result(result)
        else:
            print("❌ Prediction failed")
    else:
        # Interactive input
        while True:
            image_path = input("\n📸 Enter image path (or 'q' to quit): ").strip()
            
            if image_path.lower() == 'q':
                print("👋 Goodbye!")
                break
            
            if not os.path.exists(image_path):
                print(f"❌ File not found: {image_path}")
                continue
            
            print(f"\n🔄 Processing: {image_path}")
            result = predict(image_path, model, disease_db)
            
            if result:
                display_result(result)
            else:
                print("❌ Prediction failed")

if __name__ == '__main__':
    main()
