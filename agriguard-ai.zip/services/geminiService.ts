
import { GoogleGenAI, Type, Modality } from "@google/genai";
import { LeafAnalysisResult, SupportedLanguage, SimilarCase } from "../types";

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

export const analyzeLeaf = async (
  base64Image: string, 
  base64Audio: string | null, 
  textInput: string,
  language: SupportedLanguage
): Promise<LeafAnalysisResult> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const model = 'gemini-3-flash-preview';

  const prompt = `You are a world-class plant pathologist and agronomist. 
  Analyze this agricultural leaf image. 
  
  CONTEXT:
  - Farmer's Voice Description: ${base64Audio ? "Provided" : "None"}
  - Farmer's Text Query: "${textInput || "General health check"}"
  
  TASKS:
  1. Identify the disease or condition.
  2. Answer the farmer's specific query accurately in the 'queryExplanation' field.
  3. Provide 2-3 'similarCases' (diseases that look like this or related issues for this plant species).
  4. Provide a 'detailedCarePlan' consisting of 4-5 prioritized steps on how the farmer should take care of the diseased crop.
  
  OUTPUT REQUIREMENTS:
  - ALL descriptive text fields MUST be in ${language}.
  - The 'translatedSummary' field MUST be a natural, spoken summary in ${language} addressing the diagnosis and the user's specific query.`;

  const parts: any[] = [{ text: prompt }];
  parts.push({
    inlineData: {
      mimeType: 'image/jpeg',
      data: base64Image.split(',')[1] || base64Image,
    },
  });

  if (base64Audio) {
    parts.push({
      inlineData: {
        mimeType: 'audio/webm',
        data: base64Audio.split(',')[1] || base64Audio,
      },
    });
  }

  const response = await ai.models.generateContent({
    model,
    contents: { parts },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          condition: { type: Type.STRING },
          diagnosis: { type: Type.STRING },
          scientificName: { type: Type.STRING },
          confidenceScore: { type: Type.NUMBER },
          severity: { type: Type.NUMBER },
          symptoms: { type: Type.ARRAY, items: { type: Type.STRING } },
          recommendations: { type: Type.ARRAY, items: { type: Type.STRING } },
          suggestedTreatment: { type: Type.STRING },
          preventionTips: { type: Type.ARRAY, items: { type: Type.STRING } },
          nutritionalNeeds: { type: Type.ARRAY, items: { type: Type.STRING } },
          queryExplanation: { type: Type.STRING },
          similarCases: { 
            type: Type.ARRAY, 
            items: { 
              type: Type.OBJECT, 
              properties: {
                name: { type: Type.STRING },
                reason: { type: Type.STRING }
              }
            }
          },
          detailedCarePlan: { type: Type.ARRAY, items: { type: Type.STRING } },
          translatedSummary: { type: Type.STRING },
        },
        required: [
          "condition", "diagnosis", "confidenceScore", "severity", "symptoms", 
          "recommendations", "suggestedTreatment", "preventionTips", "nutritionalNeeds", 
          "queryExplanation", "similarCases", "detailedCarePlan", "translatedSummary"
        ],
      },
    },
  });

  if (!response.text) throw new Error("No analysis received.");

  const result = JSON.parse(response.text) as LeafAnalysisResult;

  // Enhance similar cases with generated images for visual reference
  try {
    const updatedSimilarCases = await Promise.all(
      result.similarCases.map(async (item) => {
        const imageResponse = await ai.models.generateContent({
          model: 'gemini-2.5-flash-image',
          contents: {
            parts: [{ text: `A close-up high-quality agricultural photo showing a plant leaf suffering from ${item.name}. Detailed symptoms: ${item.reason}. Realistic style, high resolution.` }],
          },
        });
        
        const imagePart = imageResponse.candidates?.[0]?.content?.parts.find(p => p.inlineData);
        return {
          ...item,
          imageUrl: imagePart ? `data:image/png;base64,${imagePart.inlineData.data}` : undefined
        };
      })
    );
    result.similarCases = updatedSimilarCases;
  } catch (imgErr) {
    console.error("Image generation for similar cases failed", imgErr);
  }

  return result;
};

export const generateSpeech = async (text: string, language: SupportedLanguage): Promise<Uint8Array> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text: `Say clearly in ${language}: ${text}` }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: 'Kore' },
        },
      },
    },
  });

  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (!base64Audio) throw new Error("Failed to generate speech");
  return decode(base64Audio);
};

export async function playPCM(data: Uint8Array) {
  const ctx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
  const audioBuffer = await decodeAudioData(data, ctx, 24000, 1);
  const source = ctx.createBufferSource();
  source.buffer = audioBuffer;
  source.connect(ctx.destination);
  source.start();
}
