
export enum HealthStatus {
  HEALTHY = 'Healthy',
  DISEASED = 'Diseased',
  NUTRIENT_DEFICIENT = 'Nutrient Deficient',
  PEST_AFFECTED = 'Pest Affected',
  UNKNOWN = 'Unknown'
}

export type SupportedLanguage = 'English' | 'Hindi' | 'Spanish' | 'French' | 'Telugu' | 'Tamil' | 'Bengali';

export type View = 'analyzer' | 'resources' | 'about' | 'register';

export type ResourceSubView = 'main' | 'diseases' | 'soil' | 'calendar';

export interface SimilarCase {
  name: string;
  reason: string;
  imageUrl?: string; // Generated image for visual reference
}

export interface LeafAnalysisResult {
  condition: HealthStatus;
  diagnosis: string;
  scientificName?: string;
  confidenceScore: number;
  severity: number;
  symptoms: string[];
  recommendations: string[];
  suggestedTreatment: string;
  preventionTips: string[];
  nutritionalNeeds: string[];
  queryExplanation: string; 
  similarCases: SimilarCase[]; 
  detailedCarePlan: string[]; 
  translatedSummary?: string;
}

export interface AnalysisState {
  isAnalyzing: boolean;
  result: LeafAnalysisResult | null;
  error: string | null;
  imagePreview: string | null;
  audioInput: string | null;
  textInput: string;
  selectedLanguage: SupportedLanguage;
}
