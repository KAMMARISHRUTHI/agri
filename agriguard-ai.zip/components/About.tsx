
import React from 'react';
import { SupportedLanguage } from '../types';

interface AboutProps {
  language: SupportedLanguage;
}

const contentMap: Record<SupportedLanguage, any> = {
  English: {
    missionTitle: "Securing the World's Food Supply",
    missionSubtitle: "Our Mission",
    missionText: "AgriGuard AI was founded to bridge the gap between advanced technology and traditional farming. Our goal is to empower small-scale farmers with enterprise-grade diagnostics.",
    storyTitle: "The AgriGuard Story",
    storyText: "Born from a collaboration between agronomists and software engineers, AgriGuard AI targets the 40% of global crop losses attributed to pests and diseases. We believe technology should be a tool for sustainability, not just productivity.",
    impact1: "Diagnostic Precision",
    impact2: "Regional Reach",
    pillar1Title: "Sustainable", pillar1Text: "Reducing chemical waste through precision.",
    pillar2Title: "Accessible", pillar2Text: "Available anytime, anywhere on your mobile.",
    pillar3Title: "Immediate", pillar3Text: "Detect infections before they spread."
  },
  Hindi: {
    missionTitle: "दुनिया की खाद्य आपूर्ति को सुरक्षित करना",
    missionSubtitle: "हमारा मिशन",
    missionText: "AgriGuard AI की स्थापना उन्नत तकनीक और पारंपरिक खेती के बीच की दूरी को कम करने के लिए की गई थी। हमारा लक्ष्य छोटे किसानों को विशेषज्ञ स्तर के निदान के साथ सशक्त बनाना है।",
    storyTitle: "AgriGuard की कहानी",
    storyText: "कृषिविदों और सॉफ्टवेयर इंजीनियरों के सहयोग से जन्मा, AgriGuard AI कीटों और बीमारियों के कारण होने वाले 40% वैश्विक फसल नुकसान को लक्षित करता है।",
    impact1: "सटीक निदान",
    impact2: "क्षेत्रीय पहुंच",
    pillar1Title: "सतत", pillar1Text: "सटीकता के माध्यम से रासायनिक कचरे को कम करना।",
    pillar2Title: "सुलभ", pillar2Text: "आपके मोबाइल पर कभी भी, कहीं भी उपलब्ध।",
    pillar3Title: "तत्काल", pillar3Text: "संक्रमण फैलने से पहले उसका पता लगाएं।"
  },
  // Simplified other languages for brevity in this block, but structure remains same
  Spanish: { missionTitle: "Asegurando el suministro de alimentos", missionSubtitle: "Nuestra Misión", missionText: "AgriGuard AI se fundó para cerrar la brecha entre la tecnología avanzada y la agricultura tradicional.", storyTitle: "La historia de AgriGuard", storyText: "Nacida de la colaboración entre agrónomos e ingenieros.", impact1: "Precisión", impact2: "Alcance", pillar1Title: "Sostenible", pillar1Text: "Reducción de residuos.", pillar2Title: "Accesible", pillar2Text: "En tu móvil.", pillar3Title: "Inmediato", pillar3Text: "Detección rápida." },
  French: { missionTitle: "Sécuriser l'approvisionnement alimentaire", missionSubtitle: "Notre Mission", missionText: "AgriGuard AI a été fondée pour combler le fossé entre la technologie et l'agriculture.", storyTitle: "L'histoire d'AgriGuard", storyText: "Née d'une collaboration entre agronomes et ingénieurs.", impact1: "Précision", impact2: "Portée", pillar1Title: "Durable", pillar1Text: "Réduction des déchets.", pillar2Title: "Accessible", pillar2Text: "Sur mobile.", pillar3Title: "Immédiat", pillar3Text: "Détection rapide." },
  Telugu: { missionTitle: "ప్రపంచ ఆహార సరఫరాను భద్రపరచడం", missionSubtitle: "మా లక్ష్యం", missionText: "అధునాతన సాంకేతికత మరియు సంప్రదాయ వ్యవసాయం మధ్య అంతరాన్ని తగ్గించడానికి అగ్రిగార్డ్ AI స్థాపించబడింది.", storyTitle: "అగ్రిగార్డ్ కథ", storyText: "శాస్త్రవేత్తలు మరియు సాఫ్ట్‌వేర్ ఇంజనీర్ల సహకారంతో పుట్టింది.", impact1: "ఖచ్చితత్వం", impact2: "ప్రాంతీయ వ్యాప్తి", pillar1Title: "స్థిరమైన", pillar1Text: "వ్యర్థాలను తగ్గించడం.", pillar2Title: "అందుబాటులో", pillar2Text: "ఎక్కడైనా లభిస్తుంది.", pillar3Title: "తక్షణం", pillar3Text: "ముందే గుర్తించడం." },
  Tamil: { missionTitle: "உலக உணவு விநியோகத்தை பாதுகாத்தல்", missionSubtitle: "எங்கள் நோக்கம்", missionText: "மேம்பட்ட தொழில்நுட்பத்திற்கும் பாரம்பரிய விவசாயத்திற்கும் இடையிலான இடைவெளியை குறைக்க அக்ரிகார்ட் AI நிறுவப்பட்டது.", storyTitle: "அக்ரிகார்ட் கதை", storyText: "விஞ்ஞானிகள் மற்றும் மென்பொருள் பொறியாளர்களின் ஒத்துழைப்பால் உருவானது.", impact1: "துல்லியம்", impact2: "பரவல்", pillar1Title: "நிலையான", pillar1Text: "கழிவுகளை குறைத்தல்.", pillar2Title: "அணுகக்கூடியது", pillar2Text: "மொபைலில் கிடைக்கும்.", pillar3Title: "உடனடியாக", pillar3Text: "முன்கூட்டியே கண்டறிதல்." },
  Bengali: { missionTitle: "বিশ্বের খাদ্য সরবরাহ সুরক্ষিত করা", missionSubtitle: "আমাদের লক্ষ্য", missionText: "উন্নত প্রযুক্তি এবং ঐতিহ্যবাহী চাষের মধ্যে ব্যবধান মেটাতে এগ্রিগার্ড এআই প্রতিষ্ঠিত হয়েছিল।", storyTitle: "এগ্রিগার্ডের গল্প", storyText: "কৃষিবিদ এবং সফটওয়্যার ইঞ্জিনিয়ারদের সহযোগিতায় জন্ম।", impact1: "নির্ভুলতা", impact2: "আঞ্চলিক বিস্তার", pillar1Title: "টেকসই", pillar1Text: "বর্জ্য হ্রাস।", pillar2Title: "সহজলভ্য", pillar2Text: "মোবাইলে উপলব্ধ।", pillar3Title: "তাত্ক্ষণিক", pillar3Text: "দ্রুত শনাক্তকরণ।" }
};

export const About: React.FC<AboutProps> = ({ language }) => {
  const t = contentMap[language] || contentMap.English;

  return (
    <div className="max-w-5xl mx-auto px-4 py-16 animate-in fade-in duration-500">
      <div className="text-center mb-20">
        <span className="text-emerald-600 font-bold tracking-widest uppercase text-sm mb-4 inline-block">{t.missionSubtitle}</span>
        <h2 className="text-5xl font-extrabold text-slate-900 heading-font mb-6 leading-tight">{t.missionTitle}, <span className="text-emerald-600">One Leaf at a Time</span></h2>
        <p className="text-slate-500 text-xl leading-relaxed max-w-3xl mx-auto italic">
          "{t.missionText}"
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center mb-32">
        <div className="space-y-6">
          <h3 className="text-3xl font-bold text-slate-900 heading-font">{t.storyTitle}</h3>
          <p className="text-slate-600 text-lg leading-relaxed">
            {t.storyText}
          </p>
          <div className="flex gap-4 pt-4">
            <div className="flex-1 p-4 bg-slate-50 rounded-2xl border border-slate-200">
              <p className="text-2xl font-bold text-emerald-600">98%</p>
              <p className="text-xs text-slate-500 uppercase font-bold tracking-tighter">{t.impact1}</p>
            </div>
            <div className="flex-1 p-4 bg-slate-50 rounded-2xl border border-slate-200">
              <p className="text-2xl font-bold text-emerald-600">Pan-India</p>
              <p className="text-xs text-slate-500 uppercase font-bold tracking-tighter">{t.impact2}</p>
            </div>
          </div>
        </div>
        <div className="bg-emerald-600 rounded-[3rem] aspect-video flex flex-col items-center justify-center text-white shadow-2xl relative p-8 text-center overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-tr from-emerald-900/50 to-transparent"></div>
            <svg className="w-16 h-16 mb-4 relative z-10" fill="currentColor" viewBox="0 0 20 20"><path d="M10 12a2 2 0 100-4 2 2 0 000 4z" /><path fillRule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clipRule="evenodd" /></svg>
            <p className="text-lg font-bold relative z-10">AgriGuard AI Project Overview</p>
            <p className="text-sm opacity-80 relative z-10">Technology Serving Farmers</p>
        </div>
      </div>

      <div className="bg-emerald-50 rounded-3xl p-12 border border-emerald-100">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div>
                <h4 className="text-slate-900 font-bold text-xl mb-2">{t.pillar1Title}</h4>
                <p className="text-slate-500 text-sm">{t.pillar1Text}</p>
            </div>
            <div>
                <h4 className="text-slate-900 font-bold text-xl mb-2">{t.pillar2Title}</h4>
                <p className="text-slate-500 text-sm">{t.pillar2Text}</p>
            </div>
            <div>
                <h4 className="text-slate-900 font-bold text-xl mb-2">{t.pillar3Title}</h4>
                <p className="text-slate-500 text-sm">{t.pillar3Text}</p>
            </div>
        </div>
      </div>
    </div>
  );
};
