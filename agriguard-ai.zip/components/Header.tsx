
import React from 'react';
import { View } from '../types';

interface HeaderProps {
  currentView: View;
  onNavigate: (view: View) => void;
}

export const Header: React.FC<HeaderProps> = ({ currentView, onNavigate }) => {
  const navItems: { label: string; view: View }[] = [
    { label: 'Analyzer', view: 'analyzer' },
    { label: 'Resources', view: 'resources' },
    { label: 'About', view: 'about' },
  ];

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-50 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div 
            className="flex items-center space-x-2 cursor-pointer group" 
            onClick={() => onNavigate('analyzer')}
          >
            <div className="bg-emerald-600 p-2 rounded-lg group-hover:bg-emerald-500 transition-colors">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
              </svg>
            </div>
            <span className="text-xl font-bold text-slate-900 heading-font">AgriGuard <span className="text-emerald-600">AI</span></span>
          </div>
          
          <nav className="hidden md:flex space-x-1 bg-slate-100 p-1 rounded-xl">
            {navItems.map((item) => (
              <button
                key={item.view}
                onClick={() => onNavigate(item.view)}
                className={`px-4 py-1.5 rounded-lg text-sm font-semibold transition-all ${
                  currentView === item.view 
                  ? 'bg-white text-emerald-600 shadow-sm' 
                  : 'text-slate-500 hover:text-emerald-600 hover:bg-white/50'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          <div className="flex items-center">
            <button 
              onClick={() => onNavigate('register')}
              className={`px-5 py-2 rounded-full text-sm font-bold transition-all border active:scale-95 ${
                currentView === 'register'
                ? 'bg-emerald-600 text-white border-emerald-600 shadow-lg'
                : 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100 shadow-sm'
              }`}
            >
              Register Farm
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
