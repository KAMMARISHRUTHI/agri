
import React, { useState } from 'react';
import { SupportedLanguage, ResourceSubView } from '../types';

interface ResourcesProps {
  language: SupportedLanguage;
}

// Fix: Use Partial to allow incremental initialization and avoid missing property errors during object creation
const resourcesI18nData: Partial<Record<SupportedLanguage, any>> = {
  English: {
    back: "Back to Resources",
    diseases: "Disease Encyclopedia",
    soil: "Soil Health Guides",
    calendar: "Planting Calendar",
    diseaseList: [
      { name: "Tomato Late Blight", desc: "Caused by Phytophthora infestans, it shows as large water-soaked spots on leaves that quickly turn brown." },
      { name: "Wheat Leaf Rust", desc: "Orange-brown pustules on leaves. It reduces crop yield by interfering with photosynthesis." },
      { name: "Rice Blast", desc: "Diamond-shaped lesions with gray centers and red borders. It can destroy entire fields if unchecked." },
      { name: "Citrus Canker", desc: "Bacterial disease causing raised brown spots on citrus fruits and leaves." }
    ],
    soilList: [
      { name: "Nitrogen Deficiency", desc: "Yellowing of older leaves (Chlorosis) starting from the mid-vein. Plant growth is stunted." },
      { name: "Phosphorus Deficiency", desc: "Leaves turn a purplish or dark green color. Root systems are poorly developed." },
      { name: "Potassium Deficiency", desc: "Edges of leaves appear scorched or brown. Stalks become weak and prone to breaking." },
      { name: "pH Imbalance", desc: "Affects nutrient uptake. Soil that is too acidic or alkaline locks away essential minerals." }
    ],
    seasons: [
      { name: "Monsoon (Kharif)", crops: "Rice, Maize, Cotton, Soybean" },
      { name: "Winter (Rabi)", crops: "Wheat, Mustard, Peas, Barley" },
      { name: "Summer (Zaid)", crops: "Cucumber, Watermelon, Sunflower" }
    ]
  },
  Hindi: {
    back: "संसाधनों पर वापस जाएं",
    diseases: "रोग विश्वकोश",
    soil: "मिट्टी स्वास्थ्य मार्गदर्शिका",
    calendar: "रोपण कैलेंडर",
    diseaseList: [
      { name: "टमाटर पछेती झुलसा", desc: "पत्तियों पर बड़े पानी से लथपथ धब्बे जो जल्दी भूरे हो जाते हैं।" },
      { name: "गेहूं की पत्ती का रतुआ", desc: "पत्तियों पर नारंगी-भूरे रंग के दाने। यह पैदावार कम करता है।" },
      { name: "धान का ब्लास्ट", desc: "ग्रे केंद्र और लाल किनारों वाले हीरे के आकार के घाव।" },
      { name: "साइट्रस कैंकर", desc: "नींबू वर्गीय फलों और पत्तियों पर उभरे हुए भूरे धब्बे।" }
    ],
    soilList: [
      { name: "नाइट्रोजन की कमी", desc: "पुरानी पत्तियों का पीला पड़ना। पौधे की वृद्धि रुक जाती है।" },
      { name: "फास्फोरस की कमी", desc: "पत्तियां बैंगनी या गहरे हरे रंग की हो जाती हैं।" },
      { name: "पोटेशियम की कमी", desc: "पत्तियों के किनारे झुलसे हुए या भूरे दिखाई देते हैं।" },
      { name: "पीएच असंतुलन", desc: "पोषक तत्वों के अवशोषण को प्रभावित करता है।" }
    ],
    seasons: [
      { name: "मानसून (खरीफ)", crops: "चावल, मक्का, कपास, सोयाबीन" },
      { name: "सर्दी (रबी)", crops: "गेहूं, सरसों, मटर, जौ" },
      { name: "गर्मी (जायद)", crops: "खीरा, तरबूज, सूरजमुखी" }
    ]
  }
};

// Map other languages to English for fallback data consistency in this demo
['Spanish', 'French', 'Telugu', 'Tamil', 'Bengali'].forEach(lang => {
  const l = lang as SupportedLanguage;
  if (!resourcesI18nData[l]) resourcesI18nData[l] = resourcesI18nData.English;
});

// Fix: Export a fully typed Record for safe consumption after filling fallbacks
const resourcesI18n = resourcesI18nData as Record<SupportedLanguage, any>;

export const Resources: React.FC<ResourcesProps> = ({ language }) => {
  const [subView, setSubView] = useState<ResourceSubView>('main');
  const t = resourcesI18n[language] || resourcesI18n.English;

  const renderContent = () => {
    switch(subView) {
      case 'diseases':
        return (
          <div className="space-y-8 animate-in slide-in-from-right-4 duration-300">
            <button onClick={() => setSubView('main')} className="flex items-center text-emerald-600 font-bold mb-4">
              <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M15 19l-7-7 7-7" strokeWidth={2} /></svg>
              {t.back}
            </button>
            <h3 className="text-3xl font-bold mb-6">{t.diseases}</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {t.diseaseList.map((d: any, i: number) => (
                <div key={i} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
                  <div className="w-12 h-12 bg-red-50 text-red-600 rounded-2xl flex items-center justify-center mb-4 text-xl">🦠</div>
                  <h4 className="text-xl font-bold mb-2">{d.name}</h4>
                  <p className="text-slate-500 text-sm leading-relaxed">{d.desc}</p>
                </div>
              ))}
            </div>
          </div>
        );
      case 'soil':
        return (
          <div className="space-y-8 animate-in slide-in-from-right-4 duration-300">
            <button onClick={() => setSubView('main')} className="flex items-center text-emerald-600 font-bold mb-4">
              <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M15 19l-7-7 7-7" strokeWidth={2} /></svg>
              {t.back}
            </button>
            <h3 className="text-3xl font-bold mb-6">{t.soil}</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {t.soilList.map((s: any, i: number) => (
                <div key={i} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
                  <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center mb-4 text-xl">🌱</div>
                  <h4 className="text-xl font-bold mb-2">{s.name}</h4>
                  <p className="text-slate-500 text-sm leading-relaxed">{s.desc}</p>
                </div>
              ))}
            </div>
          </div>
        );
      case 'calendar':
        return (
          <div className="space-y-8 animate-in slide-in-from-right-4 duration-300">
            <button onClick={() => setSubView('main')} className="flex items-center text-emerald-600 font-bold mb-4">
              <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M15 19l-7-7 7-7" strokeWidth={2} /></svg>
              {t.back}
            </button>
            <h3 className="text-3xl font-bold mb-6">{t.calendar}</h3>
            <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
              <div className="space-y-6">
                {t.seasons.map((s: any, i: number) => (
                  <div key={i} className="flex flex-col md:flex-row md:items-center justify-between p-6 bg-slate-50 rounded-2xl gap-4">
                    <div>
                      <span className="text-xs font-bold text-emerald-600 uppercase tracking-widest">{s.name}</span>
                      <h4 className="text-xl font-bold">{s.crops}</h4>
                    </div>
                    <div className="text-sm text-slate-400 font-medium">Optimal Planting Season</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );
      default:
        return (
          <>
            <div className="text-center mb-16">
              <h2 className="text-4xl font-extrabold text-slate-900 heading-font mb-4">Farmer's <span className="text-emerald-600">Knowledge Base</span></h2>
              <p className="text-slate-500 max-w-2xl mx-auto text-lg">Access expert agricultural research in {language} to help your farm thrive.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <ResourceCard 
                title={t.diseases} 
                desc="Identify common crop pathogens and their treatments." 
                icon="🦠" color="bg-red-50 text-red-600" 
                onClick={() => setSubView('diseases')} 
              />
              <ResourceCard 
                title={t.soil} 
                desc="Optimize your soil pH and nutrient levels for maximum yield." 
                icon="🌱" color="bg-emerald-50 text-emerald-600" 
                onClick={() => setSubView('soil')} 
              />
              <ResourceCard 
                title={t.calendar} 
                desc="Plan your planting and harvesting based on the seasons." 
                icon="📅" color="bg-amber-50 text-amber-600" 
                onClick={() => setSubView('calendar')} 
              />
            </div>
          </>
        );
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      {renderContent()}
    </div>
  );
};

const ResourceCard = ({ title, desc, icon, color, onClick }: any) => (
  <div onClick={onClick} className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm hover:shadow-xl transition-all group cursor-pointer active:scale-95">
    <div className={`w-12 h-12 rounded-2xl ${color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform text-2xl`}>
      {icon}
    </div>
    <h3 className="text-xl font-bold text-slate-900 mb-3">{title}</h3>
    <p className="text-slate-500 mb-6 leading-relaxed">{desc}</p>
    <button className="text-emerald-600 font-bold flex items-center group-hover:gap-2 transition-all">
      Explore
      <svg className="w-4 h-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
    </button>
  </div>
);
