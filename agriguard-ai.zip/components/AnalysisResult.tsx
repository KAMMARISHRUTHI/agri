
import React, { useState, useEffect } from 'react';
import { LeafAnalysisResult, HealthStatus, SupportedLanguage } from '../types';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { generateSpeech, playPCM } from '../services/geminiService';

interface AnalysisResultProps {
  result: LeafAnalysisResult;
  imagePreview: string;
  language: SupportedLanguage;
}

export const AnalysisResult: React.FC<AnalysisResultProps> = ({ result, imagePreview, language }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [showToast, setShowToast] = useState<string | null>(null);

  const handlePlayVoice = async () => {
    if (!result.translatedSummary) return;
    setIsPlaying(true);
    try {
      const audioData = await generateSpeech(result.translatedSummary, language);
      await playPCM(audioData);
    } catch (err) {
      console.error("Audio playback error:", err);
    } finally {
      setIsPlaying(false);
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      handlePlayVoice();
    }, 500);
    return () => clearTimeout(timer);
  }, [result.translatedSummary]);

  const handleDownload = () => {
    const reportText = `AgriGuard AI Report\nCondition: ${result.condition}\nDiagnosis: ${result.diagnosis}\nExplanation: ${result.queryExplanation}`;
    const blob = new Blob([reportText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `AgriGuard_Report_${new Date().getTime()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    triggerToast("Report Downloaded Successfully!");
  };

  const handleShare = () => {
    const text = `AgriGuard AI Diagnosis: ${result.diagnosis} (${result.condition}).`;
    navigator.clipboard.writeText(text);
    triggerToast("Diagnosis summary copied to clipboard!");
  };

  const triggerToast = (msg: string) => {
    setShowToast(msg);
    setTimeout(() => setShowToast(null), 3000);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case HealthStatus.HEALTHY: return 'text-emerald-600 bg-emerald-50 border-emerald-200';
      case HealthStatus.DISEASED: return 'text-red-600 bg-red-50 border-red-200';
      case HealthStatus.PEST_AFFECTED: return 'text-amber-600 bg-amber-50 border-amber-200';
      case HealthStatus.NUTRIENT_DEFICIENT: return 'text-blue-600 bg-blue-50 border-blue-200';
      default: return 'text-slate-600 bg-slate-50 border-slate-200';
    }
  };

  const confidenceData = [
    { name: 'Confidence', value: result.confidenceScore * 100 },
    { name: 'Remaining', value: 100 - (result.confidenceScore * 100) },
  ];

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-700 relative pb-28">
      <div className="flex justify-end gap-3">
        <button onClick={handleDownload} className="bg-white border border-slate-200 text-slate-700 px-4 py-2 rounded-xl text-sm font-semibold hover:bg-slate-50 flex items-center shadow-sm transition-all">
          Download Report
        </button>
        <button onClick={handleShare} className="bg-emerald-600 text-white px-4 py-2 rounded-xl text-sm font-semibold hover:bg-emerald-700 shadow-sm transition-all">
          Share Results
        </button>
      </div>

      <div className="bg-emerald-600 text-white rounded-[2rem] p-8 shadow-xl relative overflow-hidden group">
        <div className="relative z-10">
          <h3 className="text-xl font-bold mb-3">Expert Solution</h3>
          <p className="text-lg font-medium leading-relaxed italic">"{result.queryExplanation}"</p>
          <button onClick={handlePlayVoice} disabled={isPlaying} className={`mt-6 px-6 py-2 rounded-full bg-white text-emerald-700 font-bold text-sm flex items-center gap-2 ${isPlaying ? 'animate-pulse' : ''}`}>
             {isPlaying ? 'Playing Answer...' : 'Listen to Answer Again'}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200">
            <h3 className="text-sm font-bold text-slate-500 uppercase mb-4">Analyzed Image</h3>
            <img src={imagePreview} className="w-full h-64 object-cover rounded-xl shadow-inner bg-slate-100" alt="leaf" />
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
            <h3 className="text-sm font-bold text-slate-500 uppercase mb-4">Visual Comparisons</h3>
            <div className="space-y-4">
              {result.similarCases.map((c, i) => (
                <div key={i} className="p-3 bg-slate-50 rounded-xl border border-slate-100 overflow-hidden">
                  {c.imageUrl && <img src={c.imageUrl} className="w-full h-32 object-cover rounded-lg mb-2" alt={c.name} />}
                  <p className="text-xs font-bold text-emerald-700 mb-1">{c.name}</p>
                  <p className="text-[11px] text-slate-500">{c.reason}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
            <div className="flex justify-between items-center mb-6">
              <div>
                <span className={`px-3 py-1 rounded-full text-xs font-bold border ${getStatusColor(result.condition)}`}>
                  {result.condition}
                </span>
                <h2 className="text-2xl font-bold text-slate-900 mt-2">{result.diagnosis}</h2>
              </div>
              <div className="text-right">
                <p className="text-xs text-slate-500">Severity</p>
                <p className="text-2xl font-bold">{result.severity}%</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
              <div className="p-5 bg-slate-50 rounded-2xl border">
                <h4 className="text-sm font-bold mb-3">Visible Symptoms</h4>
                <ul className="space-y-1">
                  {result.symptoms.map((s, i) => <li key={i} className="text-sm text-slate-600">• {s}</li>)}
                </ul>
              </div>
              <div className="p-5 bg-emerald-50 rounded-2xl border">
                <h4 className="text-sm font-bold mb-3">Treatment</h4>
                <p className="text-sm text-emerald-800 leading-relaxed">{result.suggestedTreatment}</p>
              </div>
            </div>

            <div className="border-t pt-8">
              <h4 className="text-xl font-bold text-slate-900 mb-6">Crop Recovery Protocol</h4>
              <div className="space-y-4">
                {result.detailedCarePlan.map((step, i) => (
                  <div key={i} className="flex gap-4 p-5 bg-white border border-slate-200 rounded-2xl">
                    <span className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">{i+1}</span>
                    <p className="text-slate-600 text-sm">{step}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
