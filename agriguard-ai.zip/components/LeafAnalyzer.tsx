
import React, { useState, useRef } from 'react';
import { analyzeLeaf } from '../services/geminiService';
import { AnalysisState, SupportedLanguage } from '../types';
import { AnalysisResult } from './AnalysisResult';

interface LeafAnalyzerProps {
  language: SupportedLanguage;
}

export const LeafAnalyzer: React.FC<LeafAnalyzerProps> = ({ language }) => {
  const [state, setState] = useState<AnalysisState>({
    isAnalyzing: false,
    result: null,
    error: null,
    imagePreview: null,
    audioInput: null,
    textInput: '',
    selectedLanguage: language,
  });

  const [isRecording, setIsRecording] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.readAsDataURL(audioBlob);
        reader.onloadend = () => {
          setState(prev => ({ ...prev, audioInput: reader.result as string }));
        };
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (err) {
      console.error("Microphone access denied:", err);
      setState(prev => ({ ...prev, error: "Microphone access is required for voice input. Please enable permissions." }));
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
    }
  };

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      setState(prev => ({ ...prev, imagePreview: reader.result as string, error: null }));
    };
    reader.readAsDataURL(file);
  };

  const runAnalysis = async () => {
    if (!state.imagePreview) {
      alert("Please upload a leaf photo first.");
      return;
    }
    setState(prev => ({ ...prev, isAnalyzing: true, error: null }));
    try {
      const result = await analyzeLeaf(state.imagePreview, state.audioInput, state.textInput, language);
      setState(prev => ({ ...prev, result, isAnalyzing: false }));
    } catch (err: any) {
      console.error(err);
      setState(prev => ({ ...prev, isAnalyzing: false, error: err.message || 'Analysis failed. Please try a clearer photo.' }));
    }
  };

  const clearImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    setState(prev => ({ ...prev, imagePreview: null }));
  };

  const clearAudio = (e: React.MouseEvent) => {
    e.stopPropagation();
    setState(prev => ({ ...prev, audioInput: null }));
  };

  const reset = () => setState({
    isAnalyzing: false,
    result: null,
    error: null,
    imagePreview: null,
    audioInput: null,
    textInput: '',
    selectedLanguage: language,
  });

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      {!state.result ? (
        <div className="space-y-8 max-w-2xl mx-auto">
          <div className="text-center">
            <h1 className="text-4xl font-extrabold text-slate-900 mb-2 heading-font">Leaf Diagnostic Hub</h1>
            <p className="text-slate-500">Upload a photo, record audio, or type your specific concerns</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Image Box */}
            <div 
              onClick={() => fileInputRef.current?.click()}
              className="relative aspect-square bg-white rounded-3xl border-2 border-dashed border-slate-300 flex flex-col items-center justify-center cursor-pointer hover:border-emerald-500 transition-colors overflow-hidden group shadow-sm active:bg-slate-50"
            >
              {state.imagePreview ? (
                <>
                  <img src={state.imagePreview} className="w-full h-full object-cover" alt="Preview" />
                  <button 
                    onClick={clearImage}
                    className="absolute top-4 right-4 bg-red-500 text-white p-2 rounded-full hover:bg-red-600 shadow-lg active:scale-90"
                  >
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </>
              ) : (
                <>
                  <div className="bg-emerald-50 p-4 rounded-2xl mb-3 group-hover:scale-110 transition-transform">
                    <svg className="w-8 h-8 text-emerald-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                  </div>
                  <span className="text-sm font-bold text-slate-700">Add Leaf Photo</span>
                  <span className="text-xs text-slate-400 mt-1">Tap to select or capture</span>
                </>
              )}
              <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileChange} />
            </div>

            {/* Audio Box */}
            <div className={`relative aspect-square rounded-3xl border-2 flex flex-col items-center justify-center transition-all shadow-sm ${
              isRecording ? 'bg-red-50 border-red-500' : state.audioInput ? 'bg-emerald-50 border-emerald-500' : 'bg-white border-dashed border-slate-300'
            }`}>
              <div className="text-center p-6 w-full">
                <div 
                  onMouseDown={startRecording}
                  onMouseUp={stopRecording}
                  onTouchStart={startRecording}
                  onTouchEnd={stopRecording}
                  className={`w-20 h-20 rounded-full flex items-center justify-center cursor-pointer transition-all mb-4 mx-auto shadow-md ${
                    isRecording ? 'bg-red-500 animate-pulse' : state.audioInput ? 'bg-emerald-600' : 'bg-slate-100 hover:bg-slate-200'
                  } active:scale-90`}
                >
                  <svg className={`w-10 h-10 ${isRecording || state.audioInput ? 'text-white' : 'text-slate-400'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                  </svg>
                </div>
                <p className={`text-sm font-bold ${isRecording ? 'text-red-600' : 'text-slate-700'}`}>
                  {isRecording ? 'Listening...' : state.audioInput ? 'Voice Recorded' : 'Hold to Speak'}
                </p>
                <p className="text-xs text-slate-400 mt-2">Describe issues like leaf spots or pests</p>
                {state.audioInput && (
                  <button onClick={clearAudio} className="mt-4 text-xs font-bold text-red-600 hover:underline active:opacity-70">Remove Recording</button>
                )}
              </div>
            </div>
          </div>

          {/* Text Input Section */}
          <div className="space-y-3">
            <label className="text-sm font-bold text-slate-700 block ml-1">Additional Details or Specific Questions</label>
            <textarea 
              className="w-full p-4 rounded-2xl bg-white border border-slate-200 focus:ring-2 focus:ring-emerald-500 outline-none shadow-sm min-h-[100px] text-sm resize-none"
              placeholder="Example: Is this contagious to other tomato plants? Can I still harvest the fruit?"
              value={state.textInput}
              onChange={(e) => setState(prev => ({ ...prev, textInput: e.target.value }))}
            />
          </div>

          <button
            onClick={runAnalysis}
            disabled={!state.imagePreview || state.isAnalyzing}
            className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold text-lg shadow-lg hover:bg-emerald-700 disabled:opacity-50 disabled:bg-slate-300 transition-all flex items-center justify-center gap-3 active:scale-[0.98]"
          >
            {state.isAnalyzing ? (
              <><div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>Analyzing Diagnostic Data...</>
            ) : (
              <><span>Run AI Analysis</span><svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg></>
            )}
          </button>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <button onClick={reset} className="flex items-center text-slate-600 hover:text-emerald-600 font-medium active:scale-95 transition-all">
              <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
              New Diagnostic Session
            </button>
            <span className="text-xs bg-emerald-100 text-emerald-700 px-3 py-1 rounded-full font-bold uppercase tracking-tight">Multi-Modal Report</span>
          </div>
          <AnalysisResult result={state.result} imagePreview={state.imagePreview!} language={language} />
        </div>
      )}
    </div>
  );
};
