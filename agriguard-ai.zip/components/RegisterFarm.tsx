
import React, { useState } from 'react';
import { SupportedLanguage } from '../types';

interface RegisterFarmProps {
  language: SupportedLanguage;
}

const regI18n: Record<SupportedLanguage, any> = {
  English: {
    title: "Register Your Farm",
    step1: "Tell us about your farm",
    step2: "Select your primary crops",
    success: "Farm Registered!",
    btn: "Complete Registration"
  },
  Hindi: {
    title: "अपने खेत को पंजीकृत करें",
    step1: "हमें अपने खेत के बारे में बताएं",
    step2: "अपनी मुख्य फसलें चुनें",
    success: "खेत पंजीकृत हो गया!",
    btn: "पंजीकरण पूरा करें"
  },
  Spanish: { title: "Registra tu granja", step1: "Cuéntanos sobre tu granja", step2: "Selecciona tus cultivos", success: "¡Granja registrada!", btn: "Completar registro" },
  French: { title: "Inscrire votre ferme", step1: "Parlez-nous de votre ferme", step2: "Sélectionnez vos cultures", success: "Ferme inscrite !", btn: "Terminer l'inscription" },
  Telugu: { title: "మీ ఫామ్‌ను నమోదు చేయండి", step1: "మీ ఫామ్ గురించి మాకు చెప్పండి", step2: "మీ పంటలను ఎంచుకోండి", success: "ఫామ్ నమోదు చేయబడింది!", btn: "నమోదును పూర్తి చేయండి" },
  Tamil: { title: "உங்கள் பண்ணையை பதிவு செய்யுங்கள்", step1: "உங்கள் பண்ணை பற்றி சொல்லுங்கள்", step2: "உங்கள் பயிர்களைத் தேர்ந்தெடுக்கவும்", success: "பண்ணை பதிவு செய்யப்பட்டது!", btn: "பதிவை முடிக்கவும்" },
  Bengali: { title: "আপনার খামার নিবন্ধন করুন", step1: "আপনার খামার সম্পর্কে বলুন", step2: "আপনার ফসল নির্বাচন করুন", success: "খামার নিবন্ধিত হয়েছে!", btn: "নিবন্ধন সম্পন্ন করুন" }
};

export const RegisterFarm: React.FC<RegisterFarmProps> = ({ language }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    location: '',
    size: '',
    crops: [] as string[]
  });

  const t = regI18n[language] || regI18n.English;
  const crops = ['Tomato', 'Rice', 'Wheat', 'Maize', 'Soybean', 'Cotton', 'Coffee', 'Potato'];

  const toggleCrop = (crop: string) => {
    setFormData(prev => ({
      ...prev,
      crops: prev.crops.includes(crop) 
        ? prev.crops.filter(c => c !== crop) 
        : [...prev.crops, crop]
    }));
  };

  const handleNext = () => setStep(prev => prev + 1);

  if (step === 3) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center animate-in zoom-in duration-500">
        <div className="w-24 h-24 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-8">
          <svg className="w-12 h-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
          </svg>
        </div>
        <h2 className="text-4xl font-bold text-slate-900 mb-4 heading-font">{t.success}</h2>
        <p className="text-slate-500 text-lg mb-10">AgriGuard monitoring active for <strong>{formData.name}</strong>.</p>
        <button onClick={() => setStep(1)} className="text-emerald-600 font-bold border-b-2 border-emerald-600">Register another</button>
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto px-4 py-16 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="mb-12">
        <div className="flex justify-between items-center mb-8">
            {[1, 2].map(i => (
                <div key={i} className={`flex-1 h-2 rounded-full mx-1 ${step >= i ? 'bg-emerald-600' : 'bg-slate-200'}`}></div>
            ))}
        </div>
        <h2 className="text-3xl font-extrabold text-slate-900 heading-font">
            {step === 1 ? t.step1 : t.step2}
        </h2>
      </div>

      {step === 1 ? (
        <div className="space-y-6">
          <input 
            type="text" placeholder="Farm Name"
            className="w-full p-4 rounded-2xl bg-white border border-slate-200 focus:ring-2 focus:ring-emerald-500 outline-none"
            value={formData.name}
            onChange={(e) => setFormData({...formData, name: e.target.value})}
          />
          <input 
            type="text" placeholder="Location"
            className="w-full p-4 rounded-2xl bg-white border border-slate-200 focus:ring-2 focus:ring-emerald-500 outline-none"
            value={formData.location}
            onChange={(e) => setFormData({...formData, location: e.target.value})}
          />
          <button 
            disabled={!formData.name || !formData.location} onClick={handleNext}
            className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold shadow-lg"
          >
            Continue
          </button>
        </div>
      ) : (
        <div className="space-y-8">
          <div className="grid grid-cols-2 gap-4">
            {crops.map(crop => (
              <button
                key={crop} onClick={() => toggleCrop(crop)}
                className={`p-4 rounded-2xl border-2 font-bold ${
                    formData.crops.includes(crop) ? 'border-emerald-600 bg-emerald-50 text-emerald-700' : 'border-slate-100 bg-white text-slate-500'
                }`}
              >
                {crop}
              </button>
            ))}
          </div>
          <div className="flex gap-4">
            <button onClick={() => setStep(1)} className="flex-1 py-4 bg-slate-100 text-slate-600 rounded-2xl font-bold">Back</button>
            <button onClick={handleNext} disabled={formData.crops.length === 0} className="flex-[2] py-4 bg-emerald-600 text-white rounded-2xl font-bold shadow-lg">
                {t.btn}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
