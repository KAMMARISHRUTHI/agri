
import React, { useState } from 'react';
import { Header } from './components/Header';
import { LeafAnalyzer } from './components/LeafAnalyzer';
import { Resources } from './components/Resources';
import { About } from './components/About';
import { RegisterFarm } from './components/RegisterFarm';
import { View, SupportedLanguage } from './types';

const languages: { name: SupportedLanguage; flag: string; label: string }[] = [
  { name: 'English', flag: '🇺🇸', label: 'English' },
  { name: 'Hindi', flag: '🇮🇳', label: 'हिन्दी' },
  { name: 'Spanish', flag: '🇪🇸', label: 'Español' },
  { name: 'French', flag: '🇫🇷', label: 'Français' },
  { name: 'Telugu', flag: '🇮🇳', label: 'తెలుగు' },
  { name: 'Tamil', flag: '🇮🇳', label: 'தமிழ்' },
  { name: 'Bengali', flag: '🇮🇳', label: 'বাংলা' },
];

export const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>('analyzer');
  const [selectedLanguage, setSelectedLanguage] = useState<SupportedLanguage>('English');

  const renderView = () => {
    switch (currentView) {
      case 'analyzer': return <LeafAnalyzer language={selectedLanguage} />;
      case 'resources': return <Resources language={selectedLanguage} />;
      case 'about': return <About language={selectedLanguage} />;
      case 'register': return <RegisterFarm language={selectedLanguage} />;
      default: return <LeafAnalyzer language={selectedLanguage} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      <Header currentView={currentView} onNavigate={setCurrentView} />
      
      <main className="flex-grow relative pt-6">
        <div className="absolute top-0 left-0 w-full h-96 bg-gradient-to-b from-emerald-50 to-transparent -z-10 opacity-70"></div>
        
        {/* Language Selector at the Top Level */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-4">
          <div className="flex flex-wrap justify-center gap-2">
            {languages.map((lang) => (
              <button
                key={lang.name}
                onClick={() => setSelectedLanguage(lang.name)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border flex items-center gap-2 active:scale-95 ${
                  selectedLanguage === lang.name 
                  ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm' 
                  : 'bg-white text-slate-600 border-slate-200 hover:border-emerald-300 shadow-sm'
                }`}
              >
                <span>{lang.flag}</span>
                <span>{lang.label}</span>
              </button>
            ))}
          </div>
        </div>

        {renderView()}
      </main>

      <footer className="bg-white border-t border-slate-200 py-16 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-2 mb-6 cursor-pointer" onClick={() => setCurrentView('analyzer')}>
                <div className="bg-emerald-600 p-1.5 rounded-lg">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                  </svg>
                </div>
                <span className="text-lg font-bold text-slate-900 heading-font">AgriGuard AI</span>
              </div>
              <p className="text-slate-500 text-sm max-w-sm mb-6 leading-relaxed">
                AgriGuard AI provides real-time diagnostics and agricultural advice to farmers globally using the latest in Gemini AI technology.
              </p>
            </div>
            <div>
              <h5 className="text-sm font-bold text-slate-900 uppercase tracking-widest mb-6">Explore</h5>
              <ul className="space-y-4">
                <li><button onClick={() => setCurrentView('analyzer')} className="text-slate-500 text-sm hover:text-emerald-600 transition-colors">Analyzer Tool</button></li>
                <li><button onClick={() => setCurrentView('resources')} className="text-slate-500 text-sm hover:text-emerald-600 transition-colors">Resource Center</button></li>
                <li><button onClick={() => setCurrentView('register')} className="text-slate-500 text-sm hover:text-emerald-600 transition-colors">Register Farm</button></li>
              </ul>
            </div>
            <div>
              <h5 className="text-sm font-bold text-slate-900 uppercase tracking-widest mb-6">Company</h5>
              <ul className="space-y-4">
                <li><button onClick={() => setCurrentView('about')} className="text-slate-500 text-sm hover:text-emerald-600 transition-colors">Our Story</button></li>
                <li><a href="#" className="text-slate-500 text-sm hover:text-emerald-600 transition-colors">Impact Report</a></li>
                <li><a href="#" className="text-slate-500 text-sm hover:text-emerald-600 transition-colors">Support Center</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-slate-100 mt-12 pt-8 text-center text-xs text-slate-400">
            <p>© 2024 AgriGuard Systems International. Dedicated to Global Food Security.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};
